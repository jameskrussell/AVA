function AVA_gui
%View and annotate data

%Sections
% 1. file management: assign data directories
% 2. global variables


%% File management
close all
clear all
addpath(genpath(pwd))       %adds current directory (pwd) to path
%parentwd = fileparts(pwd);  %this is parent directory, eg \pleth\
%addpath(genpath([parentwd '\data\']))  %add parent directory to path

[matDir, lock_filedir, CaseListFile, folder_string, config_file] = AVA_file_locations();
[CaseList, N_case, activeindex] = loadCaseList(matDir, CaseListFile, lock_filedir, folder_string);
[invalidList, lockList, unlockList] = updateSubLists(CaseList, N_case);  
    %run this after loading CaseList

global case_dir

%% Waveform and measure characteristics
global wvs...  %defined in pleth_default_wave_parameters
   wv_label...  
   wv_select...  %wave selected for annotation or shifting
   wv_loaded...  %indexes of wv_files that are loaded for active case
   patient...    %patient annotations 
   measure...    %measures
   trans...      %transitions for patient and waveforms   
   auto_code     %string for automatically generated annotations

user = getenv('USERNAME');  %windows user name 
annot_opts_BC =  {'Force + Imp','CPR','No CPR', 'CPR Artifact'} ;


% i_wv?: index of wave corresponding to wave A/B/C/D
% i_meas?_p is the index of parent wave for measure ?
% i_meas? is index of measure A/B/C/D

global i_wvA i_wvB i_wvC i_wvD...
   i_measA_p i_measB_p i_measC_p i_measD_p ...        
   i_measA i_measB i_measC i_measD ...
   wv_opts_A wv_opts_B wv_opts_C wv_opts_D ...
   measA_p_opts measB_p_opts measC_p_opts measD_p_opts...
   measA_opts measB_opts measC_opts measD_opts

%% figure defaults

%main figure window and position (as percentage of screen)
fig_ht = 0.85 ;  %ht
fig_w = 1;   %width
figure_f_pos = [0, 0, fig_w, fig_ht];  %bottom left corner (x,y), fig wd, fig ht;
%units normalized to percentage of SCREEN SIZE
f = figure('Visible','on', 'Units','normalized', 'Name', matDir,...
   'Position', figure_f_pos, 'WindowScrollWheelFcn', @scrollwheel_callback,...
   'WindowKeyPressFcn',@dispkeyevent);   %creates figure
%assigns mouse functions
%'WindowButtonDownFcn', @wbd_callback,...
movegui(f,'north')


%Positions for windows that will hold different tables (tables are inside figure windows)
%relative to SCREEN SIZE
   figure_table_A_pos  = [0.1, 0.5, 0.22, 0.4];
   figure_table_B_pos  = [0.35, 0.5, 0.22, 0.4];
   figure_table_C_pos = [0.6, 0.5, 0.22, 0.4];
   figure_table_D_pos = [0.8, 0.5, 0.22, 0.4];
   figure_case_summary_pos = [0.35, 0.3, 0.22, 0.25];
   figure_table_segments_pos = [0.5,0.2,0.5,0.5];
   figure_patient_pos = [0.35, 0.3, 0.22, 0.25];
   
%% Other graphics parameters
set(0,'defaultuicontrolunits','normalized');   %change default units for gui controls = normalized, which is is percentage of FIGURE size
u = 0.05;  % my unit size for buttons, etc.; this is u% of figure
myalpha = 0.3; %transparency of fill
fill_scale = 0.33; %proportion of fill:y range
scaling_factor = 2/3;  %change in zoom
vert_factor = 0.2;  %vertical change in y-axis with "up" and "down" keys

% coordinates for gui components
  text_offset_gen = 1.05;   %proportion above top plot for text annotations
  wavetype_x = 18.2 * u;  %x position for wavetype label/listbox
    y_wvA = 18*u;
    y_wvB = 16*u;
    y_wvC = 14*u;
    y_wvD = 12*u;
    y_measA = 6*u;
    y_measB = 5*u;
    y_measC = 4*u;
    y_measD = 3*u;
    y_update_measures = 8*u;
    zoom_in_x = 1.5 * u;    %x position for "zoom_in" button
    zoom_out_x = 1.9 * u;   %x position for "zoom_out"
    up_down_x = 1.7 * u;    %x position for vertical position button

%x axis/time related globals
global x_offset xrange max_time cursor_time h_target time_shift time_shift_index 

% Handles
global haxes_wvA haxes_wvB haxes_wvC haxes_wvD haxes_m1 ... 
   h_wvA h_wvB h_wvC h_wvD...  %handles for waves
   h_measA h_measB h_measC h_measD ...%handles for measures
   h_annotate_panel  %handle for polygon


%% Load cases: h_newcase, h_casetype_popup, h_case_popop, case_initialize
%newcase: opens up casetype popup, which then opens up case popup

h_newcase = uicontrol(f,'Style','pushbutton','String','New Case',...
   'Position',[0,19*u,u,u],...
   'Callback',{@newcase_Callback});

h_casetype_popup = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Select case type', 'Unlocked (valid)', 'Locked (valid)', 'Not Valid', 'All'},...
   'Position',[0,13*u,2*u,6*u],...
   'Visible', 'off',...
   'Callback',{@casetype_popup_Callback});

h_case_popup = uicontrol(f, 'Style','popupmenu',...
   'Position',[0,12*u,2*u,6*u],...
   'Visible', 'off', ...  %not visible unless casetype selected
   'Callback',{@case_popup_Callback});
%h_case_popup 'String' and 'Value' are set by casetype_popup_Callback
%h_case_popup 'String' is the caselist

   function newcase_Callback(hObject, eventdata, ~)
      figure(f)
      hold off
      plot(0,0)  %this makes a blank plot, erasing previous case
      set(h_casetype_popup, 'Visible', 'on', 'Value', 1)
      set(hLockCase, 'Visible', 'off' )   %hides lock case button
      [invalidList, lockList, unlockList] = updateSubLists(CaseList, N_case);
   end

   function casetype_popup_Callback(source,eventdata)
      index_selected = get(source,'Value');  %casetype index
      list = get(source,'String');  %list of casetypes
      casetype = list{index_selected}; 
      
      switch casetype   %if isfield checks to see if sublist has any elements
         %exists doesn't give right answer, since struct exists.
         %however, struct has no fields if sublist has no elements
         %if sublist is empty, then make select caselist again
         
         case 'Select case type'
            set(h_case_popup,'Visible', 'off')
            set(h_casetype_popup, 'Value', 1) 
         case 'All'
            set(h_case_popup, 'String', {'Case', CaseList.id}, 'Visible', 'on' )            
         case 'Not Valid'
            if isfield(invalidList, 'id')
               set(h_case_popup, 'String',{'Case', invalidList.id}, 'Visible', 'on' )
            else
               set(h_case_popup,'Visible', 'off')
               set(h_casetype_popup, 'Value', 1)   %returns to 'Select case type'
            end            
         case 'Unlocked (valid)'
            if isfield(unlockList, 'id')  %are there any nonlock cases
               set(h_case_popup, 'String', {'Case', unlockList.id}, 'Visible', 'on' )
            else  %if there is no locklist, then change selection to CaseList
               set(h_case_popup, 'Visible', 'off')
               set(h_casetype_popup, 'Value', 1)
            end            
         case 'Locked (valid)'
            if isfield(lockList, 'id')  %are there any lock cases?
               set(h_case_popup, 'String', {'Case', lockList.id}, 'Visible', 'on' )
            else  %if there is no locklist, then change selection to CaseList
               set(h_case_popup, 'Visible', 'off')
               set(h_casetype_popup, 'Value', 1)
            end
      end
      
      set(h_case_popup, 'Value', 1); 
   end

   function case_popup_Callback(source,eventdata)
      index_selected = get(source,'Value');  %list index
      list = get(source,'String');  %caselist (may be CaseList or a subList)
      case_id = list{index_selected};  % casename, eg '120xxx'
      
      if index_selected ~= 1   % index 1 = 'Case'
         activeindex = find(strcmp({CaseList.id}, case_id));  %this finds index by comparing casename to full CaseList
         case_dir = [matDir case_id '\'];
         set(hWarning, 'Visible','on', 'String', 'Loading Case')
         
         [wvs, wv_files, wv_fields_import, meas_fields_import, epoch_mean_center, epoch_norm, ...
         patient, patient_variables_import, measure, auto_code, default_initial_wvs] = ...
         feval(config_file);  %resets wvs; place BEFORE importing specific case data
         
%          [wvs, wv_files, wv_fields_import, meas_fields_import, epoch_mean_center, epoch_norm, ...
%              patient, patient_variables_import, measure, auto_code, default_initial_wvs] = ...
%              default_wave_parameters();    
         [wvs, wv_loaded, wv_label, max_time, patient, measure, trans] = ...
             import_case(case_dir, wvs, wv_files, wv_fields_import, meas_fields_import, epoch_mean_center, epoch_norm,...
             patient, patient_variables_import, measure, auto_code);
         
         set(hWarning, 'Visible','off')
                 
         case_initialize(default_initial_wvs)
         figure(f)
         hold off     %this will overwrite existing plot
         plot_case()  %plots new case from start
      end
   end

   function case_initialize(default_initial_wvs)
      %sets default parameters prior to NEW case
      %called by case_popup_Callback when new case is selected  
       
       C = intersect(wv_loaded, default_initial_wvs);
       switch length(C)
           case 0
             i_wvA = []; i_wvB = []; i_wvC = []; i_wvD = [];
           case 1
             i_wvA = C(1); i_wvB = []; i_wvC = []; i_wvD = [];  
           case 2
             i_wvA = C(1); i_wvB = C(2); i_wvC = []; i_wvD = [];  
           case 3
             i_wvA = C(1); i_wvB = C(2); i_wvC = C(3); i_wvD = [];    
           case 4
             i_wvA = C(1); i_wvB = C(2); i_wvC = C(3); i_wvD = C(4);  
           otherwise
             i_wvA = []; i_wvB = []; i_wvC = []; i_wvD = [];  
       end
       
       function [wv_opts] = initialize_waves(h_popup_wv, hradio_trans, figure_table, i_wv, ...
               h_zoom_in_wv, h_zoom_out_wv, h_up_wv, h_down_wv, h_center_wv)
          wv_opts = {'Wave', wvs(wv_loaded).label}; 
          set(hradio_trans, 'Value', 0)      %button to off position
          set(figure_table, 'Visible','off')   %close all tables     
          if isempty(i_wv)
            set(h_popup_wv, 'Value', 1, 'String', wv_opts, 'ForegroundColor', 'black')
            set(hradio_trans, 'Visible','off', 'ForegroundColor', 'black')
            set(h_zoom_in_wv, 'Visible', 'off')
            set(h_zoom_out_wv, 'Visible', 'off')
            set(h_up_wv, 'Visible', 'off')
            set(h_down_wv, 'Visible', 'off') 
            set(h_center_wv, 'Visible', 'off')  
          else
            set(h_popup_wv, 'Value', i_wv+1, 'String', wv_opts, 'ForegroundColor', wvs(i_wv).color)   
            set(hradio_trans, 'Visible', 'on', 'String', wvs(i_wv).label, 'ForegroundColor', wvs(i_wv).color)  
            if isfield(wvs(i_wv), 'Valid')
              [y_valid, ~] = separate_wave_Y_by_validity(wvs(i_wv).y, wvs(i_wv).Valid);
              y_valid = y_valid(~isnan(y_valid)); %remove missing data         
              wvs(i_wv).ylimit = quantile(y_valid, [0 1]);  %y ranger is 0-100%
            else
              wvs(i_wv).ylimit = wvs(i_wv).ylimit_def;        
            end
          end
       end
       
      [wv_opts_A] = initialize_waves(h_popup_wvA, hradio_trans_A, figure_table_A, i_wvA, ...
          h_zoom_in_wvA, h_zoom_out_wvA, h_up_wvA, h_down_wvA, h_center_wvA);
      [wv_opts_B] = initialize_waves(h_popup_wvB, hradio_trans_B, figure_table_B, i_wvB, ...
          h_zoom_in_wvB, h_zoom_out_wvB, h_up_wvB, h_down_wvB, h_center_wvB);
      [wv_opts_C] = initialize_waves(h_popup_wvC, hradio_trans_C, figure_table_C, i_wvC, ...
          h_zoom_in_wvC, h_zoom_out_wvC, h_up_wvC, h_down_wvC, h_center_wvC);
      [wv_opts_D] = initialize_waves(h_popup_wvD, hradio_trans_D, figure_table_D, i_wvD, ...
          h_zoom_in_wvD, h_zoom_out_wvD, h_up_wvD, h_down_wvD, h_center_wvD);


       %Measures      
       function [meas_p_opts, meas_opts, i_meas_p, i_meas] = initialize_measures(h_popup_meas_parent, h_popup_meas)
          meas_p_opts = {'Wave', wvs(wv_loaded).label};
          set(h_popup_meas_parent, 'Value', 1, 'String', meas_p_opts)
          i_meas_p = [];
          meas_opts = {'Measure'};
          set(h_popup_meas, 'Value', 1, 'String', meas_opts, 'ForegroundColor', 'black')
          i_meas = [];
       end      

      [measA_p_opts, measA_opts, i_measA_p, i_measA] = initialize_measures(h_popup_measA_parent, h_popup_measA);
      [measB_p_opts, measB_opts, i_measB_p, i_measB] = initialize_measures(h_popup_measB_parent, h_popup_measB);
      [measC_p_opts, measC_opts, i_measC_p, i_measC] = initialize_measures(h_popup_measC_parent, h_popup_measC);
      [measD_p_opts, measD_opts, i_measD_p, i_measD] = initialize_measures(h_popup_measD_parent, h_popup_measD);
                 
      set(figure_table_segments, 'Visible','off')
      
      %set defaults for gui controls
      x_offset = 0;
      xrange = max_time;  %initial value for xstep is max_time
      set(h_time_step, 'Min', 1, 'Max', max_time, 'SliderStep',[10/max_time 120/max_time],...
         'Value', max_time)
      %sets slider to max_time to show whole case
      time_shift = [0 0]; time_shift_index = 0;  %vectors for changing offset
      
      set(hLockCase, 'Value', CaseList(activeindex).lock,  'Visible', 'on');
      %sets initial value for "locked" button to its value in CaseList
      if CaseList(activeindex).lock
         set(dcm_obj, 'Enable','off')
         set(table_A, 'ColumnEditable', false(1,2,3))  %tables are not editable
         set(table_B, 'ColumnEditable', false(1,2,3))
         set(table_C, 'ColumnEditable', false(1,2,3))
         set(table_D, 'ColumnEditable', false(1,2,3))
      else
         set(dcm_obj, 'Enable','on')
         set(table_A, 'ColumnEditable', [true,false,false])
         set(table_B, 'ColumnEditable', [true,false,false] )  %tables are editable
         set(table_C, 'ColumnEditable', [true,false,false])
         set(table_D, 'ColumnEditable', [true,false,false])
      end
      
      set(hValidCase, 'Value', CaseList(activeindex).valid,  'Visible', 'on');
      
%       if ~isempty(ClinData)
%          set(hradio_case_summary,  'Visible', 'on');
%          line0 = ['CASS: ' num2str(ClinData.id)];
%          line1 = ['Age: ' num2str(ClinData.age)];
%          line2 = ['Male: ' num2str(ClinData.male)];
%          line3 = ['Arrest No: ' num2str(ClinData.arrestno)];
%          line4 = ['Location: ' ClinData.location];
%          line5 = ['Witnessed: ' ClinData.witness_cat];
%          line6 = ['Bystander CPR: ' num2str(ClinData.byCPR)];
%          line7 = ['Initial rhythm: ' ClinData.rhythm];
%          line8 = ['Presumed cardiac: ' num2str(ClinData.cardiac)];
%          line9 = ['Response time: ' num2str(ClinData.RTFirst)];
%          line10 = ['ROSC: ' num2str(ClinData.rosc)];
%          line11 = ['Survival to admission: ' num2str(ClinData.survival_admit)];
%          line12 = ['Survival to hospital discharge: ' num2str(ClinData.survival_dc)];
%          
%          string_array = {line0 line1 line2 line3 line4 line5 line6 line7...
%             line8 line9 line10 line11 line12};
%          set(hcase_summary, 'String', string_array)
%       end
      
      set(h_case_popup, 'Visible', 'off' )  %closes case popup
      set(h_casetype_popup, 'Visible', 'off' )  %closes casetype (only open when select new case)
      
%      set(hradio_table_segments, 'Value',0)
%      set(hradio_table_segments, 'Visible','on')
      set(hupdate_meas, 'Visible','on')
      

      opts = vertcat('Intervention', patient.annot_intervent(:));
        set(h_annotate_pt_intervent, 'String', opts)      
      opts = vertcat('Compressions', patient.annot_cpr(:));
        set(h_annotate_pt_cpr, 'String', opts)    
                
      if ~isempty(patient)
         if isfield(patient, 'trans')
            set(hradio_patient_text, 'Visible', 'on')
         end
      end
      
      set(f, 'Name', case_dir)  %adds cass id to figure title
      
   end


%% LockCase and ValidCase
%LockCase:
%if locked:
%update CaseList with current date
%dcm is not enabled (therefore cannot annotate);
%trans_A, etc are backed up
hLockCase = uicontrol(f,'Style','radiobutton',...
   'String','Lock case',...
   'Value',0,...         %must be initialized with each new case
   'Position',[0,15*u,1.5*u,u],...
   'Visible', 'off',...
   'Callback',{@LockCase_Callback});

   function LockCase_Callback(source,eventdata)
      CaseList(activeindex).lock = get(source,'Value'); %1=locked, 0=not lock
      
      if CaseList(activeindex).lock
         CaseList(activeindex).date = datestr(now, 'ddmmyy');  %current date
         save(CaseListFile, 'CaseList')
         save([lock_filedir  CaseList(activeindex).id '_lock_' CaseList(activeindex).date '.mat'], 'trans')
         
         set(table_A, 'ColumnEditable', false(1,2,3))  %tables are not editable
         set(table_B, 'ColumnEditable', false(1,2,3))
         set(table_C, 'ColumnEditable', false(1,2,3))
         set(table_D, 'ColumnEditable', false(1,2,3))
      else  %unlock
         CaseList(activeindex).date = '';
         save(CaseListFile, 'CaseList')
         set(table_A, 'ColumnEditable', [true, false, false])
         set(table_B, 'ColumnEditable', [true, false, false])  %tables are editable
         set(table_C, 'ColumnEditable', [true, false, false])
         set(table_D, 'ColumnEditable', [true, false, false])
      end   
      [invalidList, lockList, unlockList] = updateSubLists(CaseList, N_case);
      
   end

%ValidCase:

hValidCase = uicontrol(f,'Style','radiobutton',...
   'String','Valid case',...
   'Value',0,...         %must be initialized with each new case
   'Position',[0,14*u,1.5*u,u],...
   'Visible', 'off',...
   'Callback',{@ValidCase_Callback});

   function ValidCase_Callback(source,eventdata)
      CaseList(activeindex).valid= get(source,'Value'); %1=locked, 0=not lock
      save(CaseListFile, 'CaseList')
      [invalidList, lockList, unlockList] = updateSubLists(CaseList, N_case);
   end

%% Select waves and measures to display

h_popup_wvA = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Wave'},...
   'Position',[wavetype_x, y_wvA, u, u],...
   'Visible', 'on',...
   'Callback',{@popup_wv_Callback});
h_popup_wvB = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Wave'},...
   'Position',[wavetype_x, y_wvB, u, u],...
   'Visible', 'on',...
   'Callback',{@popup_wv_Callback});
h_popup_wvC = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Wave'},...
   'Position',[wavetype_x, y_wvC, u, u],...
   'Visible', 'on',...
   'Callback',{@popup_wv_Callback});
h_popup_wvD = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Wave'},...
   'Position',[wavetype_x, y_wvD, u, u],...
   'Visible', 'on',...
   'Callback',{@popup_wv_Callback});

h_popup_measA_parent = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Wave'},...
   'Position',[wavetype_x, y_measA, 0.75*u, u],...
   'Visible', 'on',...
   'Callback',{@popup_meas_parent_Callback});
h_popup_measB_parent = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Wave'},...
   'Position',[wavetype_x, y_measB, 0.75*u, u],...
   'Visible', 'on',...
   'Callback',{@popup_meas_parent_Callback});
h_popup_measC_parent = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Wave'},...
   'Position',[wavetype_x, y_measC, 0.75*u, u],...
   'Visible', 'on',...
   'Callback',{@popup_meas_parent_Callback});
h_popup_measD_parent = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Wave'},...
   'Position',[wavetype_x, y_measD, 0.75*u, u],...
   'Visible', 'on',...
   'Callback',{@popup_meas_parent_Callback});

h_popup_measA = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Measure'},...
   'Position',[wavetype_x + u, y_measA, 0.75*u, u],...
   'Visible', 'on',...
   'Callback',{@popup_meas_Callback, });

h_popup_measB = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Measure'},...
   'Position',[wavetype_x + u, y_measB, 0.75*u,u],...
   'Visible', 'on',...
   'Callback',{@popup_meas_Callback});

h_popup_measC = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Measure'},...
   'Position',[wavetype_x + u, y_measC, 0.75*u, u],...
   'Visible', 'on',...
   'Callback',{@popup_meas_Callback});

h_popup_measD = uicontrol(f, 'Style','popupmenu',...
   'Value', 1, ...
   'String', {'Measure'},...
   'Position',[wavetype_x + u, y_measD, 0.75*u, u],...
   'Visible', 'on',...
   'Callback',{@popup_meas_Callback});


   function popup_wv_Callback(source,eventdata)
      index_selected = get(source,'Value');
      list = get(source,'String');
      str_selected = list(index_selected);
      
      switch source
         case h_popup_wvA
            hradio = hradio_trans_A;
         case h_popup_wvB
            hradio = hradio_trans_B;
         case h_popup_wvC
            hradio = hradio_trans_C;
         case h_popup_wvD
            hradio = hradio_trans_D;
      end
      
      if index_selected == 1   %no wave
         set(source, 'ForegroundColor', 'black')
         set(hradio, 'Visible','off')
         switch source
            case h_popup_wvA
               i_wvA = [];              
            case h_popup_wvB
               i_wvB = [];
            case h_popup_wvC
               i_wvC = [];
            case h_popup_wvD
               i_wvD = [];
         end
      else
         nwv = find(strcmp(wv_label, str_selected));
         wvs(nwv).ylimit = wvs(nwv).ylimit_def;
         set(source, 'ForegroundColor', wvs(nwv).color)
         switch source
            case h_popup_wvA
               i_wvA = nwv;
            case h_popup_wvB
               i_wvB = nwv;
            case h_popup_wvC
               i_wvC = nwv;
            case h_popup_wvD
               i_wvD = nwv;
         end
         set(hradio, 'String', wvs(nwv).label, 'ForegroundColor', wvs(nwv).color)
         set(hradio, 'Value', 0)
         set(hradio, 'Visible', 'on')
      end
      plot_case()
   end


   function popup_meas_parent_Callback(source,eventdata)
      index_selected = get(source,'Value');
      list = get(source,'String');
      meas_parent = list{index_selected};
      
      if index_selected == 1   %no wave
         set(source, 'ForegroundColor', 'black')
         switch source
            case h_popup_measA_parent
               i_measA_p = [];
            case h_popup_measB_parent
               i_measB_p = [];
            case h_popup_measC_parent
               i_measC_p = [];
            case h_popup_measD_parent
               i_measD_p = [];
         end
      else
         nwv = index_selected-1;
         set(source, 'ForegroundColor', wvs(nwv).color)      
         switch source
            case h_popup_measA_parent
               i_measA_p = nwv;
               if isfield(wvs(i_measA_p), 'meas')
                  measA_opts = {'Measure', wvs(i_measA_p).meas(:).label};
               else
                  measA_opts = {'Measure'};
               end
               set(h_popup_measA, 'String', measA_opts)               
            case h_popup_measB_parent
               i_measB_p = nwv;
               if isfield(wvs(i_measB_p), 'meas')
                  measB_opts = {'Measure', wvs(i_measB_p).meas(:).label};
               else
                  measB_opts = {'Measure'};
               end
               set(h_popup_measB, 'String', measB_opts)
            case h_popup_measC_parent
               i_measC_p = nwv;
               if isfield(wvs(i_measC_p), 'meas')
                  measC_opts = {'Measure', wvs(i_measC_p).meas(:).label};
               else
                  measC_opts = {'Measure'};
               end
               set(h_popup_measC, 'String', measC_opts)
            case h_popup_measD_parent
               i_measD_p = nwv;
               if isfield(wvs(i_measD_p), 'meas')
                  measD_opts = {'Measure', wvs(i_measD_p).meas(:).label};
               else
                  measD_opts = {'Measure'};
               end
               set(h_popup_measD, 'String', measD_opts)
         end
      end
            
   end


   function popup_meas_Callback(source,eventdata)
      index_selected = get(source,'Value');
      list = get(source,'String');
      str_selected = list(index_selected);
      
      if index_selected == 1
         set(source, 'ForegroundColor', 'black')
         switch source
            case h_popup_measA
               i_measA = [];
               set(h_measA, 'Visible','off')
            case h_popup_measB
               i_measB = [];
               set(h_measB, 'Visible','off')
            case h_popup_measC
               i_measC = [];
               set(h_measC, 'Visible','off')
            case h_popup_measD
               i_measD = [];
               set(h_measD, 'Visible','off')
               
         end
      else
         auto_refresh = get(hauto_refresh_meas,'Value'); 
         if auto_refresh
            update_meas_Callback('dummy','dummy')
         end
         
         nmeas = index_selected-1; 
         switch source
            case h_popup_measA
               i_measA = nmeas;
               set(source, 'ForegroundColor', wvs(i_measA_p).meas(nmeas).color)
            case h_popup_measB
               i_measB = nmeas;
               set(source, 'ForegroundColor', wvs(i_measB_p).meas(nmeas).color)
            case h_popup_measC
               i_measC = nmeas;
               set(source, 'ForegroundColor', wvs(i_measC_p).meas(nmeas).color)
            case h_popup_measD
               i_measD = nmeas;
               set(source, 'ForegroundColor', wvs(i_measD_p).meas(nmeas).color)
         end
      end
      plot_case()
   end

hupdate_meas   = uicontrol(f, 'Style', 'pushbutton',...
   'String','Calculate measures', 'Position', [wavetype_x, y_update_measures, 1.5*u, u],...
   'Visible', 'off',...
   'Callback',{@update_meas_Callback});

hauto_refresh_meas = uicontrol(f, 'Style', 'radiobutton',...
   'String', 'Auto-refresh measures',...
   'Value', 0,...         %must be initialized with each new case
   'Position',[wavetype_x, y_measD - u, 1.5*u, u],...
   'Visible', 'on');

hWarning = uicontrol(f, 'Style','text','String','', ...
   'Position',[10*u,10*u,3*u,3*u], 'Visible', 'off',...
   'FontSize',14);

   function update_meas_Callback(~,~)
      set(hWarning, 'Visible','on', 'String', 'Calculating measures')
      pause(0.1)
      for i = 1:length(wv_loaded)
        [wvs(wv_loaded(i)), measure] = get_wave_measure(case_dir, wvs(wv_loaded(i)), measure);  
      end
      set(hWarning, 'Visible','off')
      pause(0.1)
   end

%% plotting: fill_phase, plot_case, plot_patient, plot_EV_cc, plot_patient.vent

   function plot_case()
      figure(f);  %make sure we are on figure f
      n_meas = sum([~isempty(i_measA) ~isempty(i_measB) ~isempty(i_measC) ~isempty(i_measD)]);
      n_plot = sum([~isempty(i_wvA) ~isempty(i_wvB) ~isempty(i_wvC) ~isempty(i_wvD) n_meas~=0]) ;
      count_plot = 0;
      
      %make all controls disappear
      ycontrols_disappear() 

      function [count_plot, haxes_wv, h_wv] = plot_wave(count_plot, i_wv, h_zoom_in_wv, h_zoom_out_wv, ...
              h_up_wv, h_down_wv, h_center_wv)
         count_plot = count_plot + 1;
         haxes_wv = subplot(n_plot, 1, count_plot, 'replace', 'align');
         
         if isfield(wvs(i_wv), 'Valid')
           [x_valid, x_invalid] = separate_wave_X_by_validity(wvs(i_wv).x, wvs(i_wv).Valid);
           h_wv = plot(haxes_wv, x_valid, wvs(i_wv).y, 'Color', wvs(i_wv).color, 'linewidth', 1, 'LineStyle', '-'); 
           hold on;
           plot(haxes_wv, x_invalid, wvs(i_wv).y, 'Color', wvs(i_wv).color, 'linewidth', 1, 'LineStyle', ':'); 
         else
           h_wv = plot(haxes_wv, wvs(i_wv).x, wvs(i_wv).y, 'Color', wvs(i_wv).color, 'linewidth', 1);    
         end
         
         title(wvs(i_wv).label, 'FontWeight', 'bold', 'Color', wvs(i_wv).color)
         set(haxes_wv, 'XLimMode', 'manual', 'YLimMode', 'manual');
         set(haxes_wv, 'XLim', [x_offset x_offset+xrange])
         set(haxes_wv,'XGrid', 'on')  %shows gridlines only for x-axis=time
         set(haxes_wv, 'YLim', wvs(i_wv).ylimit);
         set(haxes_wv, 'HitTest', 'off');
         fill_phase(i_wv, haxes_wv);
         plot_cpr(haxes_wv)  ;
        
         coor = get(haxes_wv, 'Position');
         center = coor(2)+0.5*coor(4);
         set(h_zoom_in_wv, 'Visible', 'on', 'Position', [zoom_in_x, center, 0.4*u, 0.4*u])
         set(h_zoom_out_wv, 'Visible', 'on', 'Position', [zoom_out_x, center, 0.4*u, 0.4*u])
         set(h_up_wv, 'Visible', 'on', 'Position', [up_down_x, center+0.5*u, 0.4*u, 0.4*u])
         set(h_down_wv, 'Visible', 'on', 'Position', [up_down_x, center-0.5*u, 0.4*u, 0.4*u])  
         set(h_center_wv, 'Visible', 'on', 'Position', [zoom_in_x, center+u, u, 0.4*u])                
      end
          
      if (get(h_popup_wvA, 'Value') ~= 1)
          [count_plot, haxes_wvA, h_wvA] = plot_wave(count_plot, i_wvA, ...
              h_zoom_in_wvA, h_zoom_out_wvA, h_up_wvA, h_down_wvA, h_center_wvA);
      end
            
      if (get(h_popup_wvB, 'Value') ~= 1)
          [count_plot, haxes_wvB, h_wvB] = plot_wave(count_plot, i_wvB, ...
              h_zoom_in_wvB, h_zoom_out_wvB, h_up_wvB, h_down_wvB, h_center_wvB);
      end
      
      if (get(h_popup_wvC, 'Value') ~= 1)  %Value = 1 if plot, Value=0 if no plot
          [count_plot, haxes_wvC, h_wvC] = plot_wave(count_plot, i_wvC, ...
              h_zoom_in_wvC, h_zoom_out_wvC, h_up_wvC, h_down_wvC, h_center_wvC); 
      end
      
      if (get(h_popup_wvD, 'Value') ~= 1)  %Value = 1 if plot, Value=0 if no plot
          [count_plot, haxes_wvD, h_wvD] = plot_wave(count_plot, i_wvD, ...
              h_zoom_in_wvD, h_zoom_out_wvD, h_up_wvD, h_down_wvD, h_center_wvD);
      end
      
      % Measures
      
      if n_meas > 0
         count_plot = count_plot + 1;
         haxes_m1 = subplot(n_plot, 1, count_plot, 'replace');
         
         if (get(h_popup_measA, 'Value') ~= 1)
             h_measA = plot(haxes_m1, wvs(i_measA_p).meas(i_measA).x, wvs(i_measA_p).meas(i_measA).ystd,...
                  'Marker', '+', 'LineStyle', 'none', 'Color', wvs(i_measA_p).color);
             hold(haxes_m1, 'on')
         end

         if (get(h_popup_measB, 'Value') ~= 1)
            h_measB = plot(haxes_m1, wvs(i_measB_p).meas(i_measB).x, wvs(i_measB_p).meas(i_measB).ystd,...
               'Marker', '*', 'LineStyle', 'none', 'Color', wvs(i_measB_p).color); %'linewidth', 1
            hold(haxes_m1, 'on')
         end        
         
         if (get(h_popup_measC, 'Value') ~= 1)
            h_measC = plot(haxes_m1, wvs(i_measC_p).meas(i_measC).x, wvs(i_measC_p).meas(i_measC).ystd, ...
               'Marker', '.', 'LineStyle', 'none', 'Color', wvs(i_measC_p).color, 'linewidth', 1);
            hold(haxes_m1, 'on')
         end

         if (get(h_popup_measD, 'Value') ~= 1)
            h_measD = plot(haxes_m1, wvs(i_measD_p).meas(i_measD).x, wvs(i_measD_p).meas(i_measD).ystd, ...
               'Marker', 'x', 'LineStyle', 'none', 'Color', wvs(i_measD_p).color, 'linewidth', 1);
            hold(haxes_m1, 'on')
         end

%          if (get(h_popup_measA, 'Value') == 1)
%             set(h_measA, 'Visible','off')
%          else
%             %set(h_measA, 'XData', [], 'YData', [])  %deletes old measures
%             h_measA = plot(haxes_m1, wvs(i_measA_p).meas(i_measA).x, wvs(i_measA_p).meas(i_measA).ystd,...
%                'Color', wvs(i_measA_p).meas(i_measA).color, 'linewidth', 1);
%             hold(haxes_m1, 'on')
%          end
%          
%          if (get(h_popup_measB, 'Value') == 1)
%             set(h_measB, 'Visible','off')
%          else
%             %set(h_measB, 'XData', [], 'YData', [])
%             h_measB = plot(haxes_m1, wvs(i_measB_p).meas(i_measB).x, wvs(i_measB_p).meas(i_measB).ystd,...
%                'Color', wvs(i_measB_p).meas(i_measB).color, 'linewidth', 1);
%             hold(haxes_m1, 'on')
%          end
%          
%          if (get(h_popup_measC, 'Value') == 1)
%             set(h_measC, 'Visible','off')
%          else
%             %set(h_measC, 'XData', [], 'YData', [])
%             h_measC = plot(haxes_m1, wvs(i_measC_p).meas(i_measC).x, wvs(i_measC_p).meas(i_measC).ystd, ...
%                'Color', wvs(i_measC_p).meas(i_measC).color, 'linewidth', 1);
%             hold(haxes_m1, 'on')
%          end
%          
%          if (get(h_popup_measD, 'Value') == 1)
%             set(h_measD, 'Visible','off')
%          else
%             %set(h_measD, 'XData', [], 'YData', [])
%             h_measD = plot(haxes_m1, wvs(i_measD_p).meas(i_measD).x, wvs(i_measD_p).meas(i_measD).ystd, ...
%                'Color', wvs(i_measD_p).meas(i_measD).color, 'linewidth', 1);
%          end
         
         set(haxes_m1, 'XLimMode', 'manual', 'YLimMode', 'manual');
         set(haxes_m1, 'XLim', [x_offset x_offset+xrange])
         set(haxes_m1, 'YLim', [-4 4]);
         m1_ticklabels = {'-4SD' '-3SD' '-2SD' '-SD' 'median' '+SD' '+2SD' '+3SD' '+4SD'};
         m1_ticks = (-4:1:4);
         set(haxes_m1, 'YTick', m1_ticks, 'YTickLabel', m1_ticklabels);
         set(haxes_m1, 'HitTest', 'off');
      end
      
      %Patient data
      if n_plot>=1
        hplots = findobj(gcf,'type','axes');
        linkaxes(hplots(1:n_plot), 'x')

        %add text annotations
            axes(hplots(n_plot))  %this sets current axis to top plot
            my_y_limits = get(hplots(n_plot), 'YLim');
              y_patient = my_y_limits(1) + range(my_y_limits) * text_offset_gen;
                          
            noncpr_subset = subset_cell_array(patient.trans, 'cpr', 0);  
            plot_patient(noncpr_subset, '', y_patient)          
      end       
      
      %plot_patient(patient.nbp, 'BP', text_offset_nbp)
      %plot_patient(patient.meds, '', text_offset_gen)
      
      set(dcm_obj, 'Enable', 'off')  %set dcm_obj to off, because default, whenver plot is opened, is to set to on
   end

   function ycontrols_disappear()
         set(h_zoom_in_wvA, 'Visible', 'off')
         set(h_zoom_out_wvA, 'Visible', 'off')
         set(h_up_wvA, 'Visible', 'off')
         set(h_down_wvA, 'Visible', 'off')
         set(h_center_wvA, 'Visible', 'off')         
        
         set(h_zoom_in_wvB, 'Visible', 'off')
         set(h_zoom_out_wvB, 'Visible', 'off')
         set(h_up_wvB, 'Visible', 'off')
         set(h_down_wvB, 'Visible', 'off')      
         set(h_center_wvB, 'Visible', 'off')
         
         set(h_zoom_in_wvC, 'Visible', 'off')
         set(h_zoom_out_wvC, 'Visible', 'off')
         set(h_up_wvC, 'Visible', 'off')
         set(h_down_wvC, 'Visible', 'off')      
         set(h_center_wvC, 'Visible', 'off')
         
         set(h_zoom_in_wvD, 'Visible', 'off')
         set(h_zoom_out_wvD, 'Visible', 'off')
         set(h_up_wvD, 'Visible', 'off')
         set(h_down_wvD, 'Visible', 'off')      
         set(h_center_wvD, 'Visible', 'off')
    end
         
   function fill_phase(wvnum, haxes) %fills colors according to phase
       axes(haxes)
         my_ylim = wvs(wvnum).ylimit;
         y = mean(my_ylim);
         fill_width = (my_ylim(2) - my_ylim(1)) * 0.5 * fill_scale;
         Y = [y-fill_width,y-fill_width,y+fill_width,y+fill_width];        
         trans1 = wvs(wvnum).trans;
         
         if ~isempty(trans1)   
            for i = 1:size(trans1,1)-1
               t1 = trans1{i,1};   %time
               t2 = trans1{i+1,1}; %time
               X = [t1, t2, t2, t1];
               
               switch trans1{i,2}  %phase name
                  case wvs(wvnum).fill.red
                     mycolor='r';
                  case wvs(wvnum).fill.green
                     mycolor='g';
                  case wvs(wvnum).fill.yellow
                     mycolor='y';
                  case wvs(wvnum).fill.black
                     mycolor = 'black';
                  case wvs(wvnum).fill.white
                     mycolor='w';
                  case wvs(wvnum).fill.blue
                     mycolor='blue';
                  otherwise 
                     mycolor='w';  
               end
               
               hold on
               hfill_wv = fill(X, Y, mycolor, 'Parent', haxes);
               alpha(hfill_wv, myalpha);
               set(hfill_wv, 'HitTest', 'off');  %cannot select with mouseclick
            end  %for i trans
         end  %isempty
   end   %fill_phase

   function plot_cpr(haxes_wv) 
      axes(haxes_wv)
      my_ylim = get(haxes_wv, 'YLim');
      fill_width = (my_ylim(2) - my_ylim(1)) * 0.025;
      
      [cpr_subset] = subset_cell_array(patient.trans, 'cpr', 1);  
      for i = 1:size(cpr_subset,1)-1
        t1 = cpr_subset{i,1};   %time
        t2 = cpr_subset{i+1,1}; %time
        X = [t1, t2, t2, t1];
        Y = [my_ylim(2)-fill_width,my_ylim(2)-fill_width,my_ylim(2)+fill_width,my_ylim(2)+fill_width]; 
        switch cpr_subset{i,2}
            case 'No CPR'
                mycolor = 'g';
            case 'CPR'
                mycolor = 'r';
        end
        hold on
        fill(X, Y, mycolor);        
      end
   end

   function plot_patient(event_array, mylabel, y) 
      nrow = size(event_array, 1);
      if nrow>0
          for i=1:nrow
             if length(event_array{i,1}) == 1    %time has entry
                longlabel = [mylabel ' ' num2str(event_array{i,2})];
                text(event_array{i,1}, y, longlabel)
             end
          end
      end
   end

   function plot_cc(ycent)
      nrow = size(patient.cc, 1);  %number of rows of patient.cc; 1 specifies 1st dim = row
      for i=1:nrow
         if length(patient.cc{i,1}) == 1    %time has entry
            text(patient.cc{i,1}, y_event, '*')
         end
      end
   end

   function plot_vent(mypopup, ycent)
      index_selected = get(mypopup,'Value');  %1=vent, 2=CO2, 3=AMSA
      list = get(mypopup,'String');  %list of options
      selection = list{index_selected}; %selection as str
      
      if strcmp(selection, 'Vent')
         nrow = size(patient.vent, 1);
         for i=1:nrow
            if length(patient.vent{i,1}) == 1    %time has entry
               text(patient.vent{i,1}, ycent + 0.5, '*')
            end
         end
      end
   end

function  [x_valid, x_invalid] = separate_wave_X_by_validity(wave_x, wave_valid)
    x_valid = wave_x;
    invalidIdxs = wave_valid ~=1;
    x_valid(invalidIdxs) = NaN;

    x_invalid = wave_x; 
    validIdxs = wave_valid ==1;
    x_invalid(validIdxs) = NaN;
end     

function  [y_valid, y_invalid] = separate_wave_Y_by_validity(wave_y, wave_valid)
    y_valid = wave_y;
    invalidIdxs = wave_valid ~=1;
    y_valid(invalidIdxs) = NaN;

    y_invalid = wave_y; 
    validIdxs = wave_valid ==1;
    y_invalid(validIdxs) = NaN;
end     

%% X Axis (time) controls

%forward button
hForward  = uicontrol(f, 'Style','pushbutton',...
   'String','Forward','Position',[17*u,0,u,u/2],...
   'Callback',{@Forward_Callback});

   function Forward_Callback(~,~)
      % Display Forward plot of the currently selected data.
      if (x_offset + xrange) < max_time    %only advances if not at end of case
         x_offset = x_offset + xrange * 0.90;
         xlim([x_offset x_offset+xrange]);
      end
   end

%back button
hBackward  = uicontrol(f,'Style','pushbutton',...
   'String','Backward','Position',[16*u,0,u,u/2],...
   'Callback',{@Backward_Callback});

   function Backward_Callback(~,~)
      % Display Backward plot of the currently selected data.
      if  x_offset > 0
         x_offset = x_offset - xrange * 0.90;
         xlim([x_offset x_offset+xrange]);
      end
   end

h_time_step = uicontrol(f,'Style','slider', 'Position',[9*u, 0, 2*u , u/2],...
   'Callback',{@time_step_Callback});
%this is initialized in case_initialize:

   function time_step_Callback(source,~)
      xrange = get(source,'Value');
      xlim([x_offset x_offset+xrange]) ;
   end

%goto button with label
htext  = uicontrol(f, 'Style','text','String','Go to time:',...
   'Position',[2*u,0,0.75*u,u/2]);
hGoto = uicontrol(f, 'Style','edit',...
   'String','','Position',[3*u,0,u/2,u/2],...
   'Callback',{@Goto_Callback});

   function Goto_Callback(source,~)
      time_str = get(source,'String');
      x_offset = str2double(time_str);
      xlim([x_offset x_offset+xrange]);
      set(hGoto, 'String', '')  %erases entry
   end

%Advanced mouse controls

   function scrollwheel_callback(~,event)
      scroll_pct = 0.03;
      if event.VerticalScrollCount > 0   %forward
         if (x_offset + xrange) < max_time    %only advances if not at end of case
            x_offset = x_offset + xrange * scroll_pct;
            xlim([x_offset x_offset+xrange]);
         end
      elseif event.VerticalScrollCount < 0   %backward
         if  (x_offset) > 0
            x_offset = x_offset - xrange * scroll_pct;
            xlim([x_offset x_offset+xrange]);
         end
      end
   end

   function wbd_callback(src,evnt)
      if strcmp(get(src,'SelectionType'),'normal')  %left click
         Backward_Callback(999, 999)  %999 is dummy
      elseif strcmp(get(src,'SelectionType'),'alt')  %right click
         Forward_Callback(999,999)
      end
   end
% to activate this function, must add the following line to figure f definition:
% 'WindowButtonDownFcn', @wbd_callback,...
% right now, it is not activated, because it creates more problems


%% Y Axis controls: zoom_in, zoom_out

h_zoom_in_wvA   = uicontrol(f, 'Style','pushbutton',...
   'Visible', 'off',... 
   'String','Z+','Position',[zoom_in_x, y_wvA, 0.4*u, 0.4*u],...
   'Callback',{@scale_wv_Callback, scaling_factor});
h_zoom_out_wvA  = uicontrol(f, 'Style','pushbutton','Visible', 'off',...
   'String','Z-','Position',[zoom_out_x,y_wvA,0.4*u, 0.4*u],...
   'Callback',{@scale_wv_Callback, 1/scaling_factor});

h_zoom_in_wvB   = uicontrol(f,'Style','pushbutton','Visible', 'off',...
   'String','Z+','Position',[zoom_in_x,y_wvB,0.4*u, 0.4*u],...
   'Callback',{@scale_wv_Callback, scaling_factor});
h_zoom_out_wvB  = uicontrol(f,'Style','pushbutton','Visible', 'off',...
   'String','Z-','Position',[zoom_out_x,y_wvB,0.4*u, 0.4*u],...
   'Callback',{@scale_wv_Callback, 1/scaling_factor});

h_zoom_in_wvC   = uicontrol(f, 'Style','pushbutton','Visible', 'off',...
   'String','Z+','Position',[zoom_in_x,y_wvC,0.4*u, 0.4*u],...
   'Callback',{@scale_wv_Callback, scaling_factor});
h_zoom_out_wvC  = uicontrol(f, 'Style','pushbutton','Visible', 'off',...
   'String','Z-','Position',[zoom_out_x,y_wvC,0.4*u, 0.4*u],...
   'Callback',{@scale_wv_Callback, 1/scaling_factor});

h_zoom_in_wvD   = uicontrol(f, 'Style','pushbutton','Visible', 'off',...
   'String','Z+','Position',[zoom_in_x,y_wvD,0.4*u, 0.4*u],...
   'Callback',{@scale_wv_Callback, scaling_factor});
h_zoom_out_wvD  = uicontrol(f, 'Style','pushbutton','Visible', 'off',...
   'String','Z-','Position',[zoom_out_x,y_wvD,0.4*u, 0.4*u],...
   'Callback',{@scale_wv_Callback, 1/scaling_factor});

   function scale_wv_Callback(source,eventdata, factor)      
      switch source
         case {h_zoom_in_wvA, h_zoom_out_wvA}
            wvnum = i_wvA;
            haxes_wv = haxes_wvA;
         case {h_zoom_in_wvB, h_zoom_out_wvB}
            wvnum = i_wvB;
            haxes_wv = haxes_wvB;
         case {h_zoom_in_wvC, h_zoom_out_wvC}
            wvnum = i_wvC;
            haxes_wv = haxes_wvC;
         case {h_zoom_in_wvD, h_zoom_out_wvD}
            wvnum = i_wvD;
            haxes_wv = haxes_wvD;
      end  %switch
      current_y = get(haxes_wv, 'YLim');
      %wvs(wvnum).ylimit(2) =  wvs(wvnum).ylimit(1) + range(current_y) * factor;            
      half_range = range(current_y)/2;
      midpt = mean(current_y);
      wvs(wvnum).ylimit = [(midpt - half_range * factor)  (midpt + half_range * factor)];
      set(haxes_wv, 'YLim', wvs(wvnum).ylimit)
      handles = get(haxes_wv, 'Children');
      delete(handles(1:(length(handles)-2)))  %deletes all objects assoc with this subplot except line
      plot_cpr(haxes_wv)  
      fill_phase(wvnum, haxes_wv)
   end



h_up_wvA   = uicontrol(f, 'Style','pushbutton', 'String', 'Up', 'Visible', 'off',...
   'Position',[up_down_x, y_wvA, 0.4*u, 0.4*u],...
   'Callback',{@up_down_wv_Callback, -1});
h_down_wvA  = uicontrol(f, 'Style','pushbutton', 'Visible', 'off',...
   'String','Down','Position',[up_down_x,y_wvA - 0.4*u, 0.4*u, 0.4*u],...
   'Callback',{@up_down_wv_Callback, 1});

h_up_wvB   = uicontrol(f, 'Style','pushbutton', 'String', 'Up', 'Visible', 'off',...
   'Position',[up_down_x, y_wvB, 0.4*u, 0.4*u],...
   'Callback',{@up_down_wv_Callback, -1});
h_down_wvB  = uicontrol(f, 'Style','pushbutton', 'Visible', 'off',...
   'String','D','Position',[up_down_x,y_wvB - 0.4*u, 0.4*u, 0.4*u],...
   'Callback',{@up_down_wv_Callback, 1});

h_up_wvC   = uicontrol(f, 'Style','pushbutton', 'String', 'Up', 'Visible', 'off',...
   'Position',[up_down_x, y_wvC, 0.4*u, 0.4*u],...
   'Callback',{@up_down_wv_Callback, -1});
h_down_wvC  = uicontrol(f, 'Style','pushbutton', 'Visible', 'off',...
   'String','D','Position',[up_down_x,y_wvC - 0.4*u, 0.4*u, 0.4*u],...
   'Callback',{@up_down_wv_Callback, 1});

h_up_wvD   = uicontrol(f, 'Style','pushbutton', 'String', 'Up', 'Visible', 'off',...
   'Position',[up_down_x, y_wvD, 0.4*u, 0.4*u],...
   'Callback',{@up_down_wv_Callback, -1});
h_down_wvD  = uicontrol(f, 'Style','pushbutton', 'Visible', 'off',...
   'String','D','Position',[up_down_x,y_wvD - 0.4*u, 0.4*u, 0.4*u],...
   'Callback',{@up_down_wv_Callback, 1});

   function up_down_wv_Callback(source,~, factor)      
      switch source
         case {h_up_wvA, h_down_wvA}
            wvnum = i_wvA;
            haxes_wv = haxes_wvA;
         case {h_up_wvB, h_down_wvB}
            wvnum = i_wvB;
            haxes_wv = haxes_wvB;
         case {h_up_wvC, h_down_wvC}
            wvnum = i_wvC;
            haxes_wv = haxes_wvC;
         case {h_up_wvD, h_down_wvD}
            wvnum = i_wvD;
            haxes_wv = haxes_wvD;
      end  %switch
      current_y = get(haxes_wv, 'YLim');
      stepsize = factor * range(current_y) * vert_factor;
      wvs(wvnum).ylimit = current_y + stepsize;
      set(haxes_wv, 'YLim', wvs(wvnum).ylimit)
      
      axes(haxes_wv)
      handles = get(haxes_wv, 'Children');
      delete(handles(1:(length(handles)-2)))  %deletes all objects assoc with this subplot except line
      plot_cpr(haxes_wv)  
      fill_phase(wvnum, haxes_wv)
   end

h_center_wvA   = uicontrol(f, 'Style','pushbutton', 'String', 'Center', 'Visible', 'off',...
   'Position',[up_down_x, y_wvA + 0.4*u, u, 0.4*u],...
   'Callback',{@center_wv_Callback});
h_center_wvB   = uicontrol(f, 'Style','pushbutton', 'String', 'Center', 'Visible', 'off',...
   'Position',[up_down_x, y_wvB + 0.4*u, u, 0.4*u],...
   'Callback',{@center_wv_Callback});
h_center_wvC   = uicontrol(f, 'Style','pushbutton', 'String', 'Center', 'Visible', 'off',...
   'Position',[up_down_x, y_wvC + 0.4*u, u, 0.4*u],...
   'Callback',{@center_wv_Callback});
h_center_wvD   = uicontrol(f, 'Style','pushbutton', 'String', 'Center', 'Visible', 'off',...
   'Position',[up_down_x, y_wvD + 0.4*u, u, 0.4*u],...
   'Callback',{@center_wv_Callback});

   function center_wv_Callback(source,~)      
      switch source
         case {h_center_wvA}
            wvnum = i_wvA;
            haxes_wv = haxes_wvA;
         case {h_center_wvB}
            wvnum = i_wvB;
            haxes_wv = haxes_wvB;
         case {h_center_wvC}
            wvnum = i_wvC;
            haxes_wv = haxes_wvC;
         case {h_center_wvD}
            wvnum = i_wvD;
            haxes_wv = haxes_wvD;
      end  %switch

      xlimit = get(haxes_wv, 'XLim');
      i1 = find(wvs(wvnum).x >= xlimit(1), 1, 'first');   %index for 1st time
      i2 = find(wvs(wvnum).x <= xlimit(2), 1, 'last');   %index for 2nd time

      if isfield(wvs(wvnum), 'Valid')
          [y_valid, ~] = separate_wave_Y_by_validity(wvs(wvnum).y, wvs(wvnum).Valid);
          y = y_valid(i1:i2);
          y = y(~isnan(y));  %remove missing data         
          wvs(wvnum).ylimit = quantile(y, [0 1]);  %y ranger is 0-100%
      else
          y = wvs(wvnum).y(i1:i2);
          y = y(~isnan(y));  %remove missing data         
          wvs(wvnum).ylimit = quantile(y, [0 1]);  %y ranger is 0-100%          
      end
      
      set(haxes_wv, 'YLim', wvs(wvnum).ylimit)      
      %plot_case()  %need to replot, because otherwise fill cpr and fill phase are not deleted
      handles = get(haxes_wv, 'Children');
      delete(handles(1:(length(handles)-2)))  %deletes all objects assoc with this subplot except line
      plot_cpr(haxes_wv)  
      fill_phase(wvnum, haxes_wv)
   end


%% Case summary
figure_case_summary = figure('Visible','off','Units','normalized', 'Name','Case Summary',...
   'Position', figure_case_summary_pos);  %figure window

hradio_case_summary = uicontrol(f, 'Style','radiobutton',...
   'String','Case summary',...
   'Visible', 'off',...
   'Value',0,...         %default is no table
   'Position',[0*u,16*u,1.5*u,u],...
   'Callback',{@radio_case_summary_Callback});

   function radio_case_summary_Callback(source,eventdata)
      on = get(source,'Value');  %1 if selected
      if on
         set(figure_case_summary, 'Visible','on')
         figure(figure_case_summary)  %brings figure to front
      else
         set(figure_case_summary, 'Visible','off')
         figure(f)  %go to main window
      end
   end  %function

hcase_summary  = uicontrol(figure_case_summary, 'Style','text',...
   'HorizontalAlignment', 'left',...
   'Position',[0,0,1,1]);
%string will be added when case is loaded


%% tables of transition matrices for waves
%figure_table_A is the figure window that holds table_A
%table A contains data from wv(i_wvA).trans, which is a cell array

h_table_panel = uipanel('Parent', f, 'Title', 'Tables',...
   'Visible', 'on',...
   'Position', [0*u,6*u,1.5*u,7*u]);
%panel for table radio buttons: hradio_transA/B/C

figure_table_A = figure('Visible','off','Units','normalized', ...
   'Position', figure_table_A_pos);

table_A = uitable(figure_table_A, ...
   'ColumnName', {'Time', 'Phase', 'User'},...
   'Units', 'normalized', 'Position', [0,0,1,1], ...%table fills entire fig window
   'ColumnFormat',{'shortg','char', 'char'},...  %avoid scientific notation
   'CellEditCallback', {@table_Callback});
%'ColumnEditable', [true, false],... %makes all columns editable

hradio_trans_A = uicontrol('Parent', h_table_panel, 'Style','radiobutton',...
   'Value',0,...         %default is no table
   'Visible', 'off',...
   'Position',[0, 0.8, 1, 0.1],...
   'Callback',{@radio_trans_Callback});

figure_table_B = figure('Visible','off','Units','normalized', ...
   'Position', figure_table_B_pos);

table_B = uitable(figure_table_B,...
   'ColumnName', {'Time', 'Phase', 'User'},...
   'Units', 'normalized', 'Position', [0,0,1,1], ...%fills entire fig window
   'ColumnFormat',{'shortg','char', 'char'},...
   'CellEditCallback',  {@table_Callback});

hradio_trans_B = uicontrol('Parent', h_table_panel, 'Style','radiobutton',...
   'Value',0,...         %default is no table
   'Visible', 'off',...
   'Position',[0, 0.7, 1, 0.1],...
   'Callback', {@radio_trans_Callback});

figure_table_C = figure('Visible','off','Units','normalized', ...
   'Position', figure_table_C_pos);

table_C = uitable(figure_table_C, ...
   'ColumnName', {'Time', 'Phase', 'User'},...
   'Units', 'normalized', 'Position', [0,0,1,1], ...%fills entire fig window
   'ColumnFormat',{'shortg','char', 'char'},...
   'CellEditCallback', {@table_Callback});

hradio_trans_C = uicontrol('Parent', h_table_panel, 'Style','radiobutton',...
   'Value',0,...         %default is no table
   'Visible', 'off',...
   'Position',[0, 0.6, 1, 0.1],...
   'Callback',{@radio_trans_Callback});

figure_table_D = figure('Visible','off','Units','normalized', ...
   'Position', figure_table_D_pos);

table_D = uitable(figure_table_D, ...
   'ColumnName', {'Time', 'Phase', 'User'},...
   'Units', 'normalized', 'Position', [0,0,1,1], ...%fills entire fig window
   'ColumnFormat',{'shortg','char', 'char'},...
   'CellEditCallback', {@table_Callback});

hradio_trans_D = uicontrol('Parent', h_table_panel, 'Style','radiobutton',...
   'Value',0,...         %default is no table
   'Visible', 'off',...
   'Position',[0, 0.5, 1, 0.1],...
   'Callback',{@radio_trans_Callback});

% table editing callback functions
   function table_Callback(hObject, eventdata)
      %hObject = handle of calling object, eg table_A
      indices = eventdata.Indices;  %indices(1) is row, indices(2) is col of edited cell
          
      switch hObject
         case table_A
            wvnum = i_wvA;
            fighandle = figure_table_A;
         case table_B
            wvnum = i_wvB;
            fighandle = figure_table_B;
         case table_C
            wvnum = i_wvC;
            fighandle = figure_table_C;
         case table_D
            wvnum = i_wvD;
            fighandle = figure_table_D;
      end

      if strcmp(wvs(wvnum).trans(indices(1), 3), auto_code) %can't edit if user (3rd col) = auto         
         set(hObject,'Data', wvs(wvnum).trans)   %this reprints table without any changes
      else
          if indices(2)==1    %edit time=1st col; 
                 if isnan(eventdata.NewData)
                    wvs(wvnum).trans(indices(1),:) = [];
                    set(hObject,'Data', wvs(wvnum).trans)    %reprint table
                 else wvs(wvnum).trans{indices(1), indices(2)} = eventdata.NewData;
                 end
          end

          %sort and save
          wvs(wvnum).trans = sortrows(wvs(wvnum).trans, 1);
          trans.(wvs(wvnum).file) = wvs(wvnum).trans;
          save([case_dir 'trans'], 'trans')           

          %replot
          plot_case()           %replot to show edits
          figure(fighandle)  %makes table window active
            
     end
   end  %table_Callback

   function radio_trans_Callback(source, eventdata)
      on = get(source,'Value');  %1 if selected
      %first figure out which wave this is.
      %can't pass wvnum directly with function callback
      switch source
         case hradio_trans_A
            wvnum = i_wvA;
            myfigure_handle = figure_table_A;
            table_handle = table_A;
         case hradio_trans_B
            wvnum = i_wvB;
            myfigure_handle = figure_table_B;
            table_handle = table_B;
         case hradio_trans_C
            wvnum = i_wvC;
            myfigure_handle = figure_table_C;
            table_handle = table_C;
         case hradio_trans_D
            wvnum = i_wvD;
            myfigure_handle = figure_table_D;
            table_handle = table_D;
      end
      if on
         if ~isempty(wvnum)
            set(myfigure_handle, 'Visible','on')
            figure(myfigure_handle)  %brings table figure to front
            set(table_handle, 'Data', wvs(wvnum).trans)
         end
      else
         set(myfigure_handle, 'Visible','off')
         figure(f)  %go to main window
      end
   end  %function


%% measures


hradio_sd = uicontrol(f,'Style','radiobutton',...
   'String','Shock decision',...
   'Value',0,...
   'Visible','off',...
   'Position', [wavetype_x, y_update_measures - u, 1.5*u, u],...
   'Callback',{@hradio_sd_Callback});



   function hradio_sd_Callback(source,eventdata)
      plot_case()   %plot_vwm is called by plot_case
   end

%    function plot_shock_dec()
%       n = 4;
%       for j=1:length(wvs(wv_prin).meas(n).y)
%         if wvs(wv_prin).meas(n).y(j)
%            textcol='red';  %if shock decision=yes, then red
%            else textcol='green';
%         end
%         text(wvs(wv_prin).meas(n).x(j), 0, '+', 'Color', textcol, 'FontWeight', 'bold', 'FontSize', 12)
%       end
%    end

% Display pleth_segments as a table (table_segments)
%figure_table_segments is the figure window that holds table_segments
%ColumnEditable is false if case is locked for editing

figure_table_segments = figure('Visible','off','Units','normalized', 'Name', 'Transitions',...
   'Position',figure_table_segments_pos);

table_segments = uitable(figure_table_segments, ...
   'ColumnName', {'Case', 'Segment ID', 'CPR', 'Rhythm', 'Start', 'End', 'Length'},...
   'Units', 'normalized', 'Position', [0,0,1,1], ...%table fills entire fig window
   'ColumnFormat',{'char','shortg', 'char','char','shortg','shortg', 'shortg'} );
%avoid scientific notation
%'ColumnEditable', [false, false],... %all columns noneditable is
%default
%'CellEditCallback', {@table_segments_Callback});

hradio_table_segments = uicontrol('Parent', h_table_panel, 'Style','radiobutton',...
   'String','Phase summary',...
   'Value',0,...         %default is no table
   'Visible', 'off',...
   'Position',[0, 0, 1, 0.25],...
   'Callback',{@radio_table_segments_Callback});

%this is what happens when you click radio button
   function radio_table_segments_Callback(source,eventdata)
      on = get(source,'Value');  %1 if selected
      if on
         set(figure_table_segments, 'Visible','on')
         figure(figure_table_segments)  %brings figure to front
         set(table_segments,'Data', pleth_segments(:,1:7) )
         %load segments_CA 1st 6 col: case, segno, cpr, rhythm, time start,
         %time end, length
      else
         set(figure_table_segments, 'Visible','off')
         figure(f)  %go to main window
      end
   end  %function


%% Cursor Control: annotation and correcting offsets
dcm_obj = datacursormode(f);
set(dcm_obj, 'Enable', 'off', 'DisplayStyle','datatip','SnapToDataVertex','on','UpdateFcn', @annotate_fxn)
%Calls annotate_fxn when clicked if enabled
%keep disabled except when to annotate, because otherwise prevents
%WindowScrollWheelFcn

   function dispkeyevent(~, event)  %enables annotation if case not locked
      specialkey = event.Modifier;   %eg 'shift', 'alt', 'control'
      if ~isempty(specialkey)  %must be a modifier key
         if CaseList(activeindex).lock
            set(hWarning, 'Visible','on', 'String', 'Unlock case to edit')
            pause(1)
            set(hWarning, 'Visible','off')
         else
            if strcmp(specialkey, 'control')
               set(dcm_obj, 'Enable','on', 'UpdateFcn', @annotate_fxn)
               pause(0.01)  %makes matlab perform above statement
            elseif strcmp(specialkey, 'shift')
               set(h_shift_wave_panel, 'Visible', 'on')
               set(h_shift_wave_text,'String', 'Click point to move')
               set(dcm_obj, 'Enable','on', 'UpdateFcn', @shift_wave_fxn)
               pause(0.01) %makes matlab perform above statement
%             elseif strcmp(specialkey, 'alt')
%                set(dcm_obj, 'Enable','on', 'UpdateFcn', @annotate_pt_fxn)
%                pause(0.01)
            end
         end
      end
   end


%% Annotate function and make annotate options
h_annotate_panel = uipanel('Parent', f, 'Visible', 'off', 'Position', [10*u, 10*u, 3*u, 9*u]);

   function txt = annotate_fxn(~,event_obj)
      % Customizes text of data tips; update function for dcm for annotation
      pos = get(event_obj,'Position');   %position relative to figure axes
      txt = {['Time: ',num2str(pos(1))]};
      make_annotate_box()  %adds options to annotation box
      set(dcm_obj, 'Enable','off')   %
      datacursormode off;
   end

   function make_annotate_box()
      %choices for annotation, depending upon which waveform is selected
      %positions annotation panel next to cursor
      c_info = getCursorInfo(dcm_obj);
      cursor_time = c_info.Position(1);
      h_target = c_info.Target;  %handle of data object
      
      %update annotate panel
      set(h_annotate_panel, 'Visible', 'on')
      uistack(h_annotate_panel, 'top')
      
      switch h_target
         case h_wvA
            wv_select = i_wvA;
            set(h_annotate_panel, 'Title', wvs(i_wvA).label)
            opts = vertcat('Wave', wvs(i_wvA).annot_opts(:));
            set(h_annot_list, 'String', opts)
            %set(h_annot_BC, 'Visible', 'off')
            
         case h_wvB
            wv_select = i_wvB;
            set(h_annotate_panel, 'Title', wvs(i_wvB).label)
            opts = vertcat('Wave', wvs(i_wvB).annot_opts(:));
            set(h_annot_list, 'String', opts)            
            %set(h_annot_BC, 'Visible', 'on')
            
         case h_wvC
            wv_select = i_wvC;
            set(h_annotate_panel, 'Title', wvs(i_wvC).label)
            opts = vertcat('Wave', wvs(i_wvC).annot_opts(:));
            set(h_annot_list, 'String', opts)
            %set(h_annot_BC, 'Visible', 'on')
            
         case h_wvD
            wv_select = i_wvD;
            set(h_annotate_panel, 'Title', wvs(i_wvD).label)
            opts = vertcat('Wave', wvs(i_wvD).annot_opts(:));
            set(h_annot_list, 'String', opts)
            %set(h_annot_BC, 'Visible', 'on')
      end
      
   end


%% annotate waves and patient

h_annot_list = uicontrol('Parent', h_annotate_panel, 'Style','popupmenu',...
   'Value', 1, 'String', {''}, ...
   'Position',[0,0.8,1,0.2],...
   'Visible', 'on',...
   'Callback',{@annot_wv_Callback});

h_annot_BC = uicontrol('Parent', h_annotate_panel, 'Style','popupmenu',...
   'Value', 1, ...
   'String', annot_opts_BC,...
   'Position',[0,0.6,1,0.2],...
   'Visible', 'off',...
   'Callback',{@annot_wv_Callback});


   function annot_wv_Callback(hObject, eventdata)
      %hObject is either h_annot_list or h_annot_BC
      index_selected = get(hObject,'Value');  %number of item in list
      list = get(hObject,'String');  %vector options
      item_selected = list{index_selected}; % Convert from cell array
      
      switch wv_select
         case i_wvA
            tab_handle = table_A;
         case i_wvB
            tab_handle = table_B;
         case i_wvC
            tab_handle = table_C;
         case i_wvD
            tab_handle = table_D;
      end
      
      if hObject == h_annot_BC
         run_other_BC = 1;
      else run_other_BC = 0;
      end
      
      if index_selected ~= 1
         my_row = size(wvs(wv_select).trans, 1) + 1;                   
             wvs(wv_select).trans{my_row,1} = cursor_time;  %time
             wvs(wv_select).trans{my_row,2} = item_selected;
             wvs(wv_select).trans{my_row,3} = user;
             wvs(wv_select).trans = sortrows(wvs(wv_select).trans, 1);  %sorts ascending order by 1st col=time

             trans.(wvs(wv_select).file) = wvs(wv_select).trans;
             save([case_dir 'trans'], 'trans')            
             set(tab_handle, 'Data',  wvs(wv_select).trans);
         
         if run_other_BC
            if wv_select == i_wvB
               wvnum = i_wvC;
               tab_handle = table_C;
            else
               wvnum = i_wvB;
               tab_handle = table_B;
            end
            
            my_row = size(wvs(wvnum).trans, 1) + 1;
            wvs(wvnum).trans{my_row,1} = cursor_time;  %time
            wvs(wvnum).trans{my_row,2} = item_selected;
            wvs(wvnum).trans{my_row,3} = user;
            wvs(wvnum).trans = sortrows(wvs(wvnum).trans, 1);  %sorts ascending order by 1st col=time

            trans.(wvs(wv_select).file) = wvs(wv_select).trans;
            save([case_dir 'trans'], 'trans')                  
            set(tab_handle, 'Data',  wvs(wvnum).trans);
         end
      end
      
      plot_case()   %replots case
      set(h_annotate_panel, 'Visible', 'off')    %make annotate box disappear
      set(hObject, 'Value', 1)
   end


%% Annotate patient



h_annotate_pt_intervent = uicontrol('Parent', h_annotate_panel, 'Style','popupmenu',...
   'Value', 1,  'String', {'Select intervention'},...
   'Position',[0, 0.7, 1, 0.2],...
   'Visible', 'on',...
   'Callback',{@annotate_pt_Callback, 'intervent'}); 

h_annotate_pt_cpr = uicontrol('Parent', h_annotate_panel, 'Style', 'popupmenu',...
   'Value', 1,  'String', {'CPR transition'},...
   'Position',[0, 0.6, 1, 0.2],...
   'Visible', 'on',...
   'Callback',{@annotate_pt_Callback, 'cpr'}); 

h_annotate_open_textbox = uicontrol('Parent', h_annotate_panel, 'Style','pushbutton',...
   'String','Free text annotation', 'Visible', 'on',...
   'Position',[0, 0.55, 0.4, u],...
   'Callback',{@hannot_open_textbox_Callback});

h_annotate_textbox = uicontrol(h_annotate_panel, 'Style', 'edit', ...
   'String','', 'Visible', 'off',...
   'FontSize', 9, 'HorizontalAlignment', 'left', ...
   'Position',[0, 0.4, 1, 0.15], ...
   'Callback',{@annotate_enter_text_Callback});

hannot_no_entry = uicontrol('Parent', h_annotate_panel, 'Style','pushbutton',...
   'String','Cancel annotation',...
   'Visible', 'on',...
   'Position',[0.5, 0.55, 0.4, u],...
   'Callback',{@hannot_no_entry_Callback});


hannot_edit_left = uicontrol('Parent', h_annotate_panel, 'Style','popupmenu',...
   'String',{'Edit transition to left', 'Move here', 'Delete'},...
   'Value', 1, ...
   'Visible', 'on',...
   'Position',[0,0.2,1,0.1],...
   'Callback',{@hannot_edit_adjacent_Callback, 'left'});

hannot_edit_right = uicontrol('Parent', h_annotate_panel, 'Style','popupmenu',...
   'String',{'Edit transition to right', 'Move here', 'Delete'},...
   'Value', 1, ...
   'Visible', 'on',...
   'Position',[0,0.1,1,0.1],...
   'Callback',{@hannot_edit_adjacent_Callback, 'right'});

   function annotate_pt_Callback(hObject, ~, mytype)
      index_selected = get(hObject,'Value');  %number of item in list
      list = get(hObject,'String');  %vector options
      textstr = list{index_selected};
      
      if index_selected ~= 1
         nrow = size(patient.trans, 1) + 1;
         patient.trans{nrow,1} = cursor_time;  %time
         patient.trans{nrow,2} = textstr;  
         patient.trans{nrow,3} = mytype;
         patient.trans{nrow,4} = user;
         patient.trans = sortrows(patient.trans, 1);

         trans.patient = patient.trans;
         save([case_dir 'trans'], 'trans')  
                  
         set(hObject, 'Value', 1)
         set(h_annotate_panel, 'Visible', 'off')
         plot_case()      
      end
   end

   function hannot_open_textbox_Callback(~,~)
      set(h_annotate_textbox,'Visible', 'on')
      uicontrol(h_annotate_textbox)
   end

   function annotate_enter_text_Callback(source,~)
      textstr = get(source,'String');
      nrow = size(patient.trans, 1) + 1;
      patient.trans{nrow,1} = cursor_time;  %time
      patient.trans{nrow,2} = textstr;
      patient.trans{nrow,3} = 'freetext';      
      patient.trans{nrow,4} = user;      
      patient.trans = sortrows(patient.trans, 1);
      
      trans.patient = patient.trans;
      save([case_dir 'trans'], 'trans')            
      set(h_annotate_textbox, 'String', '', 'Visible', 'off')
      set(h_annotate_panel, 'Visible', 'off')
      plot_case()
   end

   function hannot_no_entry_Callback(source,eventdata)
      plot_case()   %replots case
      set(h_annotate_panel,'Visible', 'off')
   end

   function hannot_edit_adjacent_Callback(source, eventdata, direction)
      index_selected = get(source,'Value');  %number of item in list
      
      if index_selected ~= 1   %1 is no selection
         switch wv_select
            case i_wvA
               tab_handle = table_A;
            case i_wvB
               tab_handle = table_B;
            case i_wvC
               tab_handle = table_C;
            case i_wvD
               tab_handle = table_D;
         end  %switch
         
         timeVector = cell2mat(wvs(wv_select).trans(:,1));
         if strcmp(direction, 'left')
            adj_row = find(timeVector < cursor_time, 1, 'last');  %previous
         elseif strcmp(direction, 'right')
            adj_row = find(timeVector > cursor_time, 1, 'first');  %next
         end
         
         if ~strcmp(wvs(wv_select).trans(adj_row, 3), auto_code)   
             if index_selected==2      %move
                wvs(wv_select).trans{adj_row,1} = cursor_time;
             elseif index_selected==3  %delete
                wvs(wv_select).trans(adj_row,:) = [];
             end      
             trans.(wvs(wv_select).file) = wvs(wv_select).trans;
             save([case_dir 'trans'], 'trans')            
             set(tab_handle, 'Data',  wvs(wv_select).trans);
         end
         set(h_annotate_panel, 'Visible', 'off')
         set(source, 'Value', 1)  %go to top of menu
         plot_case()   %replots case
      end
   end

%% Edit patient struct in table
% tables to edit patient struct
    figure_patient_text = figure('Visible','off','Units','normalized', 'Position', figure_patient_pos);

    table_patient_text = uitable(figure_patient_text, ...
       'ColumnName', {'Time', 'Event', 'Type', 'User'},...
       'Units', 'normalized', 'Position', [0,0,1,1], ...%table fills entire fig window
       'ColumnFormat',{'shortg','char', 'char', 'char'},...  %avoid scientific notation
       'ColumnWidth', {'auto' 'auto' 'auto', 'auto'}, ...   %width must be pixels (96 pixels/in)
       'ColumnEditable', [true, true, false, false],...
       'CellEditCallback', {@table_patient_Callback});

    hradio_patient_text = uicontrol('Parent', h_table_panel, 'Style','radiobutton',...
       'Value',0,  'String', 'Patient', ...
       'Visible', 'off',...
       'Position',[0, 0.2, 1, 0.25],...
       'Callback',{@radio_patient_Callback});

   function radio_patient_Callback(source, eventdata)
      on = get(source,'Value');  %1 if selected
      if on          
         if isfield(patient, 'trans')
            set(figure_patient_text, 'Visible','on')
            figure(figure_patient_text)  %brings table figure to front
            set(table_patient_text, 'Data', patient.trans)
         end
      else
         set(figure_patient_text, 'Visible','off')
         figure(f)  %go to main window
      end
   end  %function

   function table_patient_Callback(hObject, eventdata)
      indices = eventdata.Indices;  %indices(1) is row, indices(2) is col of edited cell     
      if strcmp(patient.trans(indices(1), 4), auto_code) 
           set(hObject,'Data', patient.trans)   %this reprints table without any changes
      else
          if indices(2)==1    %edit time=1st col
             if isnan(eventdata.NewData)
                patient.trans(indices(1),:) = [];
                set(hObject,'Data', patient.trans)    %reprint table
             else patient.trans{indices(1), indices(2)} = eventdata.NewData;
             end
          else
             patient.trans{indices(1), indices(2)} = eventdata.NewData;
          end

          %sort and save
          patient.trans = sortrows(patient.trans, 1);
          trans.patient = patient.trans;
          save([case_dir 'trans'], 'trans')        

          %replot
          plot_case()           %replot to show edits
          figure(figure_patient_text)  %makes table window active
      
      end
   end  %table_Callback


%% Correcting wave offsets

%when make a change, best to call plot_case to reset
%hshift_position = [10*u, 0*u, 2*u, 4*u];
%set(h_shift_wave_panel, 'Position', [u, 10*u, 2*u, 4*u])

h_shift_wave_panel = uipanel('Parent', f, 'Title','', 'Visible', 'off',...
   'Position', [10*u, u, 2*u, 4*u]);
h_shift_wave_text = uicontrol('Parent', h_shift_wave_panel, 'Style','text',...
   'Position', [0,0.8,1,0.2], 'FontSize', 10);
h_confirm_move = uicontrol('Parent', h_shift_wave_panel, 'Style','pushbutton',...
   'String', 'Confirm move wave',...
   'Position', [0,0.6,1,0.2], 'Visible', 'off',...
   'Callback',{@hconfirm_move_Callback} );
h_cancel_move = uicontrol('Parent', h_shift_wave_panel, 'Style','pushbutton',...
   'String', 'Cancel',...
   'Position', [0,0.2,1,0.2], 'Visible', 'on',...
   'Callback',{@hcancel_move_Callback} );

   function txt = shift_wave_fxn(~,event_obj)  %for tip;
      % Customizes text of data tips
      pos = get(event_obj,'Position');   %position relative to figure axes
      txt = {['time: ',num2str(pos(1))]};
      
      c_info = getCursorInfo(dcm_obj);
      h_target = c_info.Target;
      cursor_time = c_info.Position(1);
      
      %update annotate panel position so that shows up under target
      axis_position = get(haxes_wvA, 'Position');   %coord of plot region; need 1st 2 components
      %hshift_position = [axis_position(1) + (cursor_time-x_offset)/xrange * axis_position(3)  ,...
      % axis_position(2) + c_info.Position(2)/ylimit(1) *axis_position(4), 2*u, 4*u];
      switch h_target
         case h_wvA
            wv_select = i_wvA;
         case h_wvB
            wv_select = i_wvB;
         case h_wvC
            wv_select = i_wvC;
         case h_wvD
            wv_select = i_wvD;
      end
      
      if wvs(wv_select).may_shift %any(wv_select == wv_shift)
         time_shift_index = time_shift_index + 1;
         
         if time_shift_index==1
            time_shift(time_shift_index) = pos(1);
            set(h_shift_wave_panel, 'Visible', 'on')
            set(h_shift_wave_text, 'String', 'Click destination')
         elseif time_shift_index==2
            time_shift(time_shift_index) = pos(1);
            set(h_shift_wave_panel, 'Visible', 'on')
            set(h_confirm_move, 'Visible', 'on')
         else
            set(h_shift_wave_panel, 'Visible', 'off')
            set(h_confirm_move, 'Visible', 'off')
            set(dcm_obj, 'Enable','off')
            time_shift_index = 0;
            plot_case()
         end
      else
         set(h_shift_wave_panel, 'Visible', 'off')
         set(h_confirm_move, 'Visible', 'off')
         time_shift_index = 0;
         set(hWarning, 'Visible','on', 'String', 'Cannot shift this wave')
         pause(2)
         set(hWarning, 'Visible','off')
         set(dcm_obj, 'Enable','off')
         plot_case()
      end
   end

   function hcancel_move_Callback(source,eventdata)
      set(h_shift_wave_panel, 'Visible', 'off')
      set(h_confirm_move, 'Visible', 'off')
      set(dcm_obj, 'Enable','off')
      time_shift_index = 0;
      plot_case()
   end


   function hconfirm_move_Callback(source,eventdata)
      % c_info = getCursorInfo(dcm_obj);
      %h_target = c_info.Target;  %handle of data object
      
      x1 = find(wvs(wv_select).x==time_shift(1));   %index for 1st time
      x2 = find(wvs(wv_select).x==time_shift(2));   %index for 2nd time
      record_change(time_shift, x1, x2, wv_select);
      
      npts = abs(x2 - x1);  %take absolute value
      yshift = wvs(wv_select).y;  % local variable for convenience
      len = length(yshift);
      if x2 > x1
         yshift(x2:len) = yshift(x1:(len-npts));
         yshift(x1:(x2-1)) = yshift(x1-1) * ones(1, npts);
         %repeats last value before x1 for npts
      else  % x2 < x1
         temp = yshift(x1:len);
         yshift(x2:(x2 + length(temp)-1)) = temp;
         yshift((x2 + length(temp)) : len) = yshift(len-npts) * ones(1, npts);
         %repeats last value for npts
      end
      wvs(wv_select).y = yshift;
      %%%%% Must fix this to save to shift.mat instead of overwriting
      %%%%% wave.mat
%       S=[];
%       S.(wvs(wv_select).label) = wvs(wv_select);  %save wvs
%       filename = [case_dir wvs(wv_select).label];
%       save(filename, '-struct', 'S')
      %end
      
      set(h_shift_wave_panel, 'Visible', 'off')
      set(h_confirm_move, 'Visible', 'off')
      set(dcm_obj, 'Enable','off')
      time_shift_index = 0;
      plot_case()
      
   end

   function record_change(times, x1, x2, wavenum)
      if ~isfield(wvs(wv_select), 'shifts')   %make shifts array if necessary
         wvs(wv_select).shifts = cell(0,5);
      end
      %cols: old time, new time, old index, new index, wave
      shift_row = size(wvs(wv_select).shifts,1) + 1;
      wvs(wv_select).shifts{shift_row,1} = times(1);  %time
      wvs(wv_select).shifts{shift_row,2} = times(2);
      wvs(wv_select).shifts{shift_row,3} = x1;  %time
      wvs(wv_select).shifts{shift_row,4} = x2;
      wvs(wv_select).shifts{shift_row,5} = wvs(wavenum).label;
   end


end %function pleth_viewer_gui

