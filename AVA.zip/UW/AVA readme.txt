README.TXT for pleth_viewer_gui
Date: 3/5/2014. Uploaded to Dropbox: APACHI/tools/matlab/scratchpad/Heemun
Author: Heemun Kwok

Dependent functions:
pleth_file_locations
pleth_loadCaseList
updateSubLists
pleth_default_wave_parameters
pleth_import_case
Valid_to_trans_v1
RemoveEmptyRowsCA
pleth_normalize_wv
pleth_get_wave_measure_new


Before running the gui, it is necessary to modify the following files:

1. pleth_file_locations.m
-rename "matDir", which is the folder containing the data folders
-each data folder corresponds to a single case

2. pleth_default_wave_parameters.m
-this contains default viewing parameters for each waveform
-parameters:
  -color
  -annotation options
  -fill (fill color for each annotation)
  -yview: 'raw', 'nonlinear_norm', 'median_norm'
  -default ylimits (ylimit_def)
  -meas_ABP: names of measures for this waveform, along with default color

Additionally, there are patient annotation options:
  -annot_intervent
  -annot_cpr

Instructions for gui:
1. Case types: unlocked (may be annotated), locked (cannot be annotated), not valid (something wrong with case and won't be annotated).  Case type can be changed using buttons on left

2. After case is loaded, you can select wave to view. 

3. Time control: slider controls zoom.  Backward/forward are self-explanatory.  can also use scroll wheel to advance/reverse through case.

4.  Y axis can be changed for each wave using controls on left: Z+ = zoom in, Z- = zoom out, "Up" moves entire waveform upwards, and "Down" does opposite.

5. Annotation.  To open the annotation box, hit "ctrl" and then select the wave/time with the cursor (it should be a cross-hair).  This opens a menu, which allows annotation of that wave or the patient (eg intervention or Compressions or Free text).  Additionally, it can be used to edit previous annotations ("Edit transtion to left" , "Edit transtion to right").  

6.  Annotations can be viewed and edited in table format by opening tables using the radio buttons on the left.  To modify the time of annotation, simply edit the time. To delete an entry, select the time and delete it.  Note that only non-automatic annotations may be edited.

7. Patient annotations are shown at the top of the figure.  CPR annotations are shown by the solid line at the top of each subplot: green = no cpr, red = cpr.














DATA STRUCTURE notes
Annotations are saved in trans.mat and waveform measures are saved in measures.mat
Here is some information about the primary variables:

1. wvs. structure array containing each wave struct.  Created each time a case is loaded
Default fields (defined ?in pleth_default_wave_parameters.m): file, color, fill, annot_opts, ylimit_def, yview, may_shift, meas
Imported fields: defined by wv_fields_import = waveform, waveform_n, sps, T, Valid, label

2. wv_loaded.  indexes of waves with data loaded for active case.  
 
3. measure = structure array.  This contains same data as meas field of wave structs, but is used for storage.  fields = wave filenames (Not wave labels, as some wave labels may contain spaces, and can't be used as field names)

4. patient = structure array.  Patient annotations. fields = annot_intervent, annot_cpr, and trans.
patient.trans = cell array with 4 columns: time, annotation, category (cpr, intervent), source (automatic or windows user).  This variable is created each time a case is loaded.  Data for patient.trans is stored in trans.mat (variables = trans, field = patient)

5. trans = structure array for storing all trans cell arrays for each wave and for patient. Fields: wave filenames (not labels) and 'patient'. Saved in trans.mat





