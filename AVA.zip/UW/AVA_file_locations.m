function [matDir, lock_filedir, CaseListFile, folder_string, config_file] = AVA_file_locations()
% comment/uncomment for each project

%% APACHE
matDir = 'E:\Sync\sandbox\APACHI\AVA\';  
  %director of data folders (one folder per case)
addpath(genpath(matDir))  
lock_filedir = [matDir 'lock\'];  %backup directory of locked transition matrices
CaseListFile = [matDir 'CaseList.mat'];  %this file contains spreadsheet of cases; 
%automatically created in matDir, so should not be edited
folder_string = 'MU*.??';  %pattern for data folder names

config_file = @APACHE_default_wave_parameters;  
  %configuration file; must be preceded by @;




%% CLIP

% matDir = 'C:\Users\Heemun\Documents\Research\VF\clip\Data\CASS_matfiles_v1\'; 
%   %director of data folders (one folder per case)
% addpath(genpath(matDir))  
% lock_filedir = [matDir 'lock\'];  %backup directory of locked transition matrices
% CaseListFile = [matDir 'CaseList.mat'];  %this file contains spreadsheet of cases; 
% %automatically created in matDir, so should not be edited
% folder_string = '1_12*';  %pattern for data folder names
% 
% config_file = @clip_default_wave_parameters;  
%   %configuration file; must be preceded by @;

end