function [ x ] = RemoveEmptyRowsCA( x )
%deletes empty rows of a cell array x
x(all(cellfun(@isempty,x),2), : ) = [] ;

end

