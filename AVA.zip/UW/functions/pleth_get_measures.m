function [wvs, pleth_segments, wv_meas] = pleth_get_measures(wvs, wv_loaded, pleth_segments, ...
   case_id, case_filename)


wv_meas = [];

ABP_index = 1;



if any(ABP_index==wv_loaded)
   [pleth_segments] = ExtractABPSegments(case_id, wvs(PCI_index).trans, wvs(FORC_index).trans,...
      wvs(ECG1_index).trans, wvs(ECG1_index));
   %arguments for ExtractSegments: mycase, trans_pci, trans_forc, trans_ecg, ECG1 as struct
   %segments _CA may be an empty cell array if no defined segments
   %1 case id
   %2 segment id
   %3 CPR
   %4 rhythm
   %5 start time
   %6 end time
   %7 length (sec)
   %8 cell array VWM_1s {endtime, flats, clas, pka, shock decision}
   %9 cell array VWM_4s {time, flats, clas, pka, SD}
end

[wvs, wv_meas] = assign_ABP_meas_from_segments(wvs, wv_meas);

   function [wvs, wv_meas] = assign_ABP_meas_from_segments(wvs, wv_meas)
      meas = struct('label', ABP_label, 'color', ABP_color, 'x',[], 'y', [], 'ystd', []);
      
      %make vwm vectors
      if ~isempty(pleth_segments)
         nrows = size(pleth_segments, 1);
         counter = 1;
         for i=1:nrows
            VWM_1sec = pleth_segments{i,8};   %array
            nrows_VWM = size(VWM_1sec,1);
            if ~isempty(VWM_1sec)
               for j=1:length(ABP_label)
                  meas(j).x(counter:counter+nrows_VWM-1) =  VWM_1sec(:,1);
                  meas(j).y(counter:counter+nrows_VWM-1) =  VWM_1sec(:,j+1);
               end
               counter = counter + nrows_VWM;
            end
         end
         if counter > 1
            wv_meas = [wv_meas ECG1_index];
            for i=1:length(ABP_label)
               meas(i).ystd = (meas(i).y - mean(meas(i).y)) / std(meas(i).y);
            end
            wvs(ECG1_index).meas = meas;
            S = [];
            S.ECG_segments = pleth_segments;
            S.(wvs(ECG1_index).label) = wvs(ECG1_index);
            save(case_filename, '-struct', 'S', '-append')
         end
      end
   end






end
