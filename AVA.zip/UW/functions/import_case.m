function [wvs, wv_loaded, wv_label, max_time, patient, measure, trans] = import_case(case_dir, wvs, wv_files, ...
    wv_fields_import, meas_fields_import, epoch_mean_center, epoch_norm, patient, patient_variables_import,...
    measure, auto_code)
%2/10/2014
%adapted from pleth_import_data_for_viewer.m, pleth_make_y, and
%pleth_make_transition_arrays
%
%inputs:
% case_dir = case-specific folder
% wvs (field have default parameters)
% wv_files = wvs to load, if they exist (defined in
% pleth_default_wave_parameters.m)
% wv_fields_import = fields of wvs struct to load, if exist (defined in
% pleth_default_wave_parameters.m)
% epoch_mean_center, epoch_norm, auto_code, and valid_code are passed on to
% other fucntions
% patient struct (with default parameters)
% trans_fields_import

%also makes max_time variable


wv_loaded = [];  %clears wv_loaded
wv_label = cell(1, length(wv_files));


%% load  measure file that contains trans and measure fields for all waves and
%patient
transfile = [case_dir 'trans.mat'];  
if exist(transfile, 'file')
  load(transfile);  %load trans struct
end

measfile = [case_dir 'measures.mat'];  
if exist(measfile, 'file')
  M = load(measfile);  %load measure struct into M
end
    
    
%% load patient variables
for i = 1: length(patient_variables_import)
   if exist([patient_variables_import{i} '.mat'], 'file')
      P = load(patient_variables_import{i});
      patient.(patient_variables_import{i}) = P.(patient_variables_import{i});
   end
end




%% to load waves: (1) import fields from wave mat file; (2) make trans array 

function [trans] = make_default_trans(wave, auto_code)  
% creates default trans cell array for a given wave
% Start wave and End wave created at beginning and end, as long as not empty
    trans = cell(2, 3);  
    if ~isempty(wave)     
      trans(1, 1:3) = {0, 'Start wave', auto_code};
      trans(2, 1:3) = {wave.T(end), 'End wave', auto_code};
    end
end


for i = 1:length(wv_files)
    filename = [case_dir wv_files{i} '.mat'];
  
    if exist(filename, 'file')
        S = load(filename);
        
        for j = 1:length(wv_fields_import)    %loop over fields to import
            if isfield(S.(wv_files{i}), wv_fields_import{j})
                wvs(i).(wv_fields_import{j}) = S.(wv_files{i}).(wv_fields_import{j});
            end
        end

        %time vector
        if size(wvs(i).T, 1) == 1  %horizontal vector
          wvs(i).x = wvs(i).T';
        else
          wvs(i).x = wvs(i).T;
        end
        
        %make trans field from Valid field if it doesn't exist already or is empty (otherwise will overwrite)
            if exist('trans', 'var')
                if isfield(trans, wv_files{i})
                    if isempty(trans.(wv_files{i}))
                        overwrite_trans_wv = 1;
                    else overwrite_trans_wv = 0;
                    end
                else overwrite_trans_wv = 1;
                end
            else overwrite_trans_wv = 1;
            end
            
            if overwrite_trans_wv                
                [trans.(wv_files{i})] = make_default_trans(wvs(i), auto_code);  
            end
            wvs(i).trans = trans.(wv_files{i});
        
        %make field: y
            switch wvs(i).yview
                case 'raw'
                    if size(wvs(i).waveform, 1) == 1  %horizontal vector
                      wvs(i).y = wvs(i).waveform';
                    else
                      wvs(i).y = wvs(i).waveform;
                    end  
                case 'zeromean' 
                    y = wvs(i).waveform;
                    y(isnan(y)) = 0;
                    wvs(i).y = ConvertWV_zeromean(y, epoch_mean_center, wvs(i).sps);                   
                case 'median_norm'
                    wvs(i).y = normalize_wv(wvs(i), epoch_norm, 50);
                case 'nonlinear_norm'
                    wvs(i).y = wvs(i).waveform_n;
                case 'log_median_norm'
                    wave_norm = normalize_wv(wvs(i), epoch_norm, 50);
                    wvs(i).y = log(wave_norm);
            end

        % load measures from M.measure, if it exists, and combine with
        % measure struct defaults
        % otherwise add empty fields            
            if exist('M', 'var')
                if isfield(M.measure, wvs(i).file)
                   load_meas = 1;
                else load_meas = 0;
                end
            else load_meas = 0;
            end
            
            for j = 1:length(meas_fields_import)    %loop over fields, eg x, y, ystd
                for k = 1:length(wvs(i).meas)       %loop over each measure, eg median, max, min
                  if load_meas
                      measure.(wvs(i).file)(k).(meas_fields_import{j}) = M.measure.(wvs(i).file)(k).(meas_fields_import{j});
                  else
                      measure.(wvs(i).file)(k).(meas_fields_import{j}) = [];
                  end                      
                  wvs(i).meas(k).(meas_fields_import{j}) = measure.(wvs(i).file)(k).(meas_fields_import{j});
                end
            end

        
        
        %if this wave may be shifted, then incorporate tabulated shifts into y
        if wvs(i).may_shift && isfield(wvs(i), 'shifts')
            for j=1:size(wvs(i).shifts, 1)
                time_shift(1) = wvs(i).shifts{j,1};
                time_shift(2) = wvs(i).shifts{j,2};
                
                x1 = find(wvs(i).x <= time_shift(1), 1, 'last');  %closest index to 1st time
                x2 = find(wvs(i).x <= time_shift(2), 1, 'last');
                
                npts = abs(x2 - x1);  %take absolute value
                len = length(wvs(i).y);
                if x2 > x1
                    wvs(i).y(x2:len) = wvs(i).y(x1:(len-npts));
                    wvs(i).y(x1:(x2-1)) = wvs(i).y(x1-1) * ones(1, npts);
                    %repeats last value before x1 for npts
                else  % x2 < x1
                    temp = wvs(i).y(x1:len);
                    wvs(i).y(x2:(x2 + length(temp)-1)) = temp;
                    wvs(i).y((x2 + length(temp)) : len) = wvs(i).y(len-npts) * ones(1, npts);
                    %repeats last value for npts
                end
            end
        end
        
        % save
        wv_loaded = [wv_loaded i];
        wv_label{i} = wvs(i).label;
        clear S SS  overwrite_trans_wv load_meas
    end
end

all_times = vertcat(wvs(1:length(wv_files)).x);
max_time = max(all_times);


%% Load or create trans field of patient 
% must place after loading waves, because requires max_time

   
if exist('trans', 'var')   
    if isfield(trans, 'patient')
        if isempty(trans.patient)
            overwrite_trans_pt = 1;
        else overwrite_trans_pt = 0;
        end
    else overwrite_trans_pt = 1;
    end
else overwrite_trans_pt = 1;
end

    if overwrite_trans_pt   %add a start and end
        trans.patient = cell(0,4);
        trans.patient{1,1} = 0;
        trans.patient{1,2} = 'No CPR';
        trans.patient{1,3} = 'cpr';
        trans.patient{1,4} = auto_code;
        
        trans.patient{2,1} = max_time;
        trans.patient{2,2} = 'No CPR';
        trans.patient{2,3} = 'cpr';
        trans.patient{2,4} = auto_code;           
    end
    
patient.trans = trans.patient;
clear overwrite_trans_pt






end
