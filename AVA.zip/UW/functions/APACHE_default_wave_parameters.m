function [wvs, wv_files, wv_fields_import, meas_fields_import, epoch_mean_center, epoch_norm, ...
    patient, patient_variables_import, measure, auto_code, default_initial_wvs] =...
     APACHE_default_wave_parameters()
% identifies waveforms and default parameters
% these parameters are the same for every case
% there will be a different version, depending upon data source, eg MRX v
%pleth
% also identifies fields of waveform structs to import from raw data files


%% patient:
 annot_intervent = {{'Shock', 'ECLS', 'Epinephrine', 'Lidocaine', 'Dopamine'}};
 annot_cpr = {{'CPR', 'No CPR', 'CPR unknown'}};
 patient_variables_import =  {};  
 patient = struct('annot_intervent', annot_intervent, 'annot_cpr', annot_cpr);


%% wavestructs
wv_files = {'ABP', 'Oxy1IR', 'Oxy2IR', 'NicoIR', 'ECG'};
wv_fields_import =  {'waveform', 'waveform_n', 'sps', 'T', 'Valid', 'label'};
meas_fields_import = {'x', 'y', 'ystd'};
epoch_mean_center = 10;  %for detrending and mean-centering waves
epoch_norm = 10;  %for median normalization
auto_code = 'auto';  %label for automatic annotation; pass to pleth_import_case -> Valid_to_trans_v1
default_initial_wvs = (1:4);  %numbers refer to wv_files index

%parameters: color, fill, annotation options, yview, default y limit 
    %yview options = 'raw', 'zeromean', 'median_norm', 'nonlinear_norm', 'log_median_norm',
    ir_limits = [1e04 1e06];
    median_norm_limits = [0.97 1.03];
    nonlinear_norm_limits = [-3 3];
    zeromean_limits = [-1000 1000];

%ABP
     color_ABP = 'blue';
     annot_opts_ABP = { 'valid', 'occluded', 'artifact', 'blood draw'};
     fill_ABP = struct('blue', {{'occluded', 'artifact', 'blood draw'}},...
         'green', {{'valid'}}, ...
         'red', {{}},...
         'yellow', {{}},...
         'black', {{'not valid'}},...
         'white', {{}});  %note double brackets to make struct with cell array as field

     yview_ABP = 'raw';
     ylimit_def_ABP = [-50 200];   
     may_shift_ABP = 0;
     meas_ABP =   struct(...
         'label', {'maximum', 'minimum', 'median'}, ...
         'color', {'red', 'blue', 'green'}, ...
         'yview', {'ystd', 'ystd', 'ystd'}...
     );  
     
%NicoIR (FingerIR)
     color_NicoIR = 'm';
     annot_opts_NicoIR = {'valid', 'artifact'};
     fill_NicoIR = struct('blue', {{'artifact'}},...
         'green', {{'valid'}}, ...
         'red', {{}},...
         'yellow', {{}},...
         'black', {{'not valid'}},...
         'white', {{}}); 
      yview_NicoIR = 'raw';
      ylimit_def_NicoIR = ir_limits;
%      yview_NicoIR = 'zeromean';
%      ylimit_def_NicoIR = zeromean_limits; 
%      yview_NicoIR = 'nonlinear_norm';
%      ylimit_def_NicoIR = nonlinear_norm_limits; 
     may_shift_NicoIR = 0;
     meas_NicoIR =  struct(...
         'label', {'maximum', 'minimum', 'median'}, ...
         'color', {'red', 'blue', 'green'}, ...
         'yview', {'ystd', 'ystd', 'ystd'}...
     );  
 
%Oxy1IR (NoseIR)
     color_Oxy1IR = 'm';
     annot_opts_Oxy1IR = annot_opts_NicoIR;
     fill_Oxy1IR = fill_NicoIR;
%      yview_Oxy1IR = 'raw';
%      ylimit_def_Oxy1IR = ir_limits;
     yview_Oxy1IR = 'nonlinear_norm'; 
     ylimit_def_Oxy1IR = nonlinear_norm_limits;   
     may_shift_Oxy1IR = 0;
     meas_Oxy1IR =  struct(...
         'label', {'maximum', 'minimum', 'median'}, ...
         'color', {'red', 'blue', 'green'}, ...
         'yview', {'ystd', 'ystd', 'ystd'}...
     );  
 
%Oxy2IR (EarIR)
     color_Oxy2IR = 'm';
     fill_Oxy2IR = fill_NicoIR;
     annot_opts_Oxy2IR = annot_opts_NicoIR;
%      yview_Oxy2IR = 'raw';
%      ylimit_def_Oxy2IR = ir_limits;
     yview_Oxy2IR = 'nonlinear_norm'; 
     ylimit_def_Oxy2IR = nonlinear_norm_limits;
     may_shift_Oxy2IR = 0;
     meas_Oxy2IR =  struct(...
         'label', {'maximum', 'minimum', 'median'}, ...
         'color', {'red', 'blue', 'green'}, ...
         'yview', {'ystd', 'ystd', 'ystd'}...
     );  
 
%ECG     
     color_ECG = 'b';
     annot_opts_ECG = {'artifact', 'organized', 'VF', 'VT', 'asystole', 'unknown'};
     fill_ECG = struct('blue', {{'artifact'}},...
         'green', {{'valid', 'organized'}}, ...
         'red', {{'VF', 'VT'}},...
         'yellow', {{'asystole'}},...
         'black', {{'not valid'}},...
         'white', {{'unknown'}});
     yview_ECG = 'raw'; 
     ylimit_def_ECG = [-0.2 1];  
     may_shift_ECG = 0;
     meas_ECG = struct(...
         'label', {'AMSA'}, ...
         'color', {'red'}, ...
         'yview', {'ystd'}...
     );
 
% put all waves into a struct          
  wv_ylimit_default = {ylimit_def_ABP, ylimit_def_NicoIR, ylimit_def_Oxy1IR, ylimit_def_Oxy2IR, ylimit_def_ECG};
  wv_color = {color_ABP, color_NicoIR, color_Oxy1IR, color_Oxy2IR, color_ECG};  
  wv_fill = {fill_ABP, fill_NicoIR, fill_Oxy1IR, fill_Oxy2IR, fill_ECG};
  wv_annot_opts = {annot_opts_ABP, annot_opts_NicoIR, annot_opts_Oxy1IR, annot_opts_Oxy2IR, annot_opts_ECG};
  wv_yview = {yview_ABP, yview_NicoIR, yview_Oxy1IR, yview_Oxy2IR, yview_ECG};
  wv_may_shift = {may_shift_ABP, may_shift_NicoIR, may_shift_Oxy1IR, may_shift_Oxy2IR, may_shift_ECG};
  wv_meas = {meas_ABP, meas_NicoIR, meas_Oxy1IR, meas_Oxy2IR, meas_ECG};
  
 wvs = struct('file', wv_files, 'color', wv_color, 'fill', wv_fill, ...
     'annot_opts', wv_annot_opts, 'ylimit_def', wv_ylimit_default,...
     'yview', wv_yview, 'may_shift', wv_may_shift, 'meas', wv_meas);

  
  

 
%meas  wv_files = {'ABP', 'Oxy1IR', 'Oxy2IR', 'NicoIR', 'ECG'};
 for i = 1:length(wv_files)
    measure.(wv_files{i}) = wv_meas{i};
 end
 
end

