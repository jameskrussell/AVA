function [Csub] = subset_cell_array(C, str_cond, include)
%Cs = cellfun(f, C) 
%   - C:            the source cell array
%   - f:            the predicate function handle
%   - Cs:           the cell array of selected elements (same size as C)
% C(cellfun(f, C) )  returns only those matching elements
% eg, cellfun(@(x) length(x) > 3, C)

Cs = cellfun(@(x) strcmp(x, str_cond), C);

[rownum, colnum] = find(Cs == 1);
if include
  Csub = C(rownum, :);
else
  n = size(C, 1);
  Csub = C(setdiff(1:n, rownum), :);
end


end

